# Evidencia GA7-220501096-AA5-EV04 – Módulo web con Servlets y JSP

## Adaptación realizada
Se conservó el proyecto original y su funcionamiento. Únicamente se agregó el módulo independiente
`ModuloWebServlet` para cumplir el requisito de codificación web con Java.

## Relación con artefactos
El módulo representa el caso de uso **Gestionar usuarios**, la entidad **Usuario** y las operaciones
registrar, consultar y eliminar, manteniendo la separación Modelo, DAO y Controlador.

## Requisitos cumplidos
- Formularios HTML: formulario de registro.
- Servlet: `UsuarioServlet`.
- Método GET: `doGet()` para consultas y navegación.
- Método POST: `doPost()` para procesar formularios.
- JSP: vistas dinámicas para listado, formulario y errores.
- JDBC: acceso a SQL Server mediante `UsuarioDAO` y `ConexionBD`.
- Versionamiento: el proyecto conserva `.gitignore` y puede gestionarse con Git.

## Arquitectura
`HTML/JSP -> Servlet -> DAO -> JDBC -> SQL Server`

La adaptación se realizó agregando archivos nuevos, sin reemplazar la conexión ni los archivos funcionales
del proyecto original.
