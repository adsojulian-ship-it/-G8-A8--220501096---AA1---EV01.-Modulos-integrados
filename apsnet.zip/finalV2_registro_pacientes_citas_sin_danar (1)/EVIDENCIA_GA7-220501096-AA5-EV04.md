# GA7-220501096-AA5-EV04 – Codificación del módulo del proyecto

## 1. Descripción de la adaptación
El proyecto **Clínica Asistente IA** se adapta a la evidencia mediante la incorporación del módulo independiente `ModuloJDBC`, conservando intacto el proyecto ASP.NET original.

La adaptación permite demostrar explícitamente el uso de **Java Database Connectivity (JDBC)** con SQL Server y un ciclo completo CRUD.

## 2. Relación con los artefactos del ciclo de software
| Artefacto | Aplicación en el proyecto |
|---|---|
| Diagrama de clases | Se refleja en las capas Modelo (`Usuario`), DAO (`UsuarioDAO`) y Configuración (`ConexionBD`). |
| Casos de uso | Registrar, consultar, actualizar y eliminar usuarios. |
| Historias de usuario | El usuario administrador gestiona las cuentas del sistema. |
| Diseños y prototipos | El proyecto original contiene las interfaces de gestión; el módulo JDBC implementa su persistencia como evidencia técnica. |
| Plan de trabajo | Se implementa una arquitectura por paquetes y responsabilidades separadas. |

## 3. Conexión JDBC
La clase `ConexionBD` crea conexiones mediante `DriverManager.getConnection()`. La clase `UsuarioDAO` utiliza `Connection`, `CallableStatement` y `ResultSet`.

## 4. Funcionalidades requeridas
- Inserción: `insertar(Usuario usuario)`
- Consulta: `consultar()`
- Actualización: `actualizar(Usuario usuario)`
- Eliminación: `eliminar(int idUsuario)`

## 5. Estándares de codificación
- Clases en PascalCase: `UsuarioDAO`, `ConexionBD`.
- Métodos y variables en camelCase: `obtenerConexion`, `idUsuario`.
- Paquetes en minúsculas: `co.edu.sena.clinica.dao`.
- Uso de `try-with-resources` para cierre automático de recursos JDBC.
- Separación por responsabilidades.

## 6. Versionamiento
El archivo `.gitignore` y las instrucciones de Git permiten llevar el proyecto a un repositorio GitHub. Se recomienda realizar commits por funcionalidad:
1. `feat: conexión JDBC`
2. `feat: inserción de usuarios`
3. `feat: consulta de usuarios`
4. `feat: actualización de usuarios`
5. `feat: eliminación de usuarios`
6. `docs: evidencia GA7-AA5-EV04`

## 7. Observación técnica
El proyecto original está desarrollado en C# y usa ADO.NET. JDBC es una tecnología propia de Java; por esta razón se añadió un módulo Java/JDBC separado en lugar de cambiar o dañar la conexión SQL Server existente del proyecto original.
