# Módulo Web con Servlets y JSP

Este módulo fue agregado sin modificar el funcionamiento del proyecto original.

## Tecnologías
- Java 17
- Maven
- Jakarta Servlet
- JSP
- HTML
- JDBC
- SQL Server
- Tomcat 10.1 o compatible

## Requisitos de la evidencia
- Formularios HTML: `usuario-form.jsp`
- Servlet: `UsuarioServlet`
- GET: `doGet()` para consulta, navegación y eliminación
- POST: `doPost()` para registrar y actualizar
- JSP: `usuarios.jsp`, `usuario-form.jsp`, `error.jsp`
- JDBC: reutiliza la misma configuración del módulo JDBC existente
- Versionamiento: se conserva `.gitignore` del proyecto

## Ejecución
1. Abrir la carpeta `ModuloWebServlet` en IntelliJ IDEA, Eclipse o NetBeans.
2. Ejecutar `mvn clean package`.
3. Desplegar `target/ClinicaWebServlet.war` en Tomcat 10.1+.
4. Abrir:
   `http://localhost:8080/ClinicaWebServlet/`

> La conexión JDBC usa SQL Server y puede configurarse mediante las variables de entorno
> `DB_URL`, `DB_USER` y `DB_PASSWORD`.
