<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Error</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<main class="contenedor">
    <h1>Ocurrió un error</h1>
    <p><%= request.getAttribute("mensajeError") %></p>
    <a class="boton" href="usuarios">Volver a usuarios</a>
</main>
</body>
</html>
