<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Registrar usuario</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<main class="contenedor">
    <h1>Registrar usuario</h1>

    <!-- Formulario HTML enviado al Servlet mediante POST -->
    <form action="usuarios" method="post">
        <input type="hidden" name="accion" value="registrar">

        <label>Usuario</label>
        <input type="text" name="usuario" required maxlength="50">

        <label>Clave</label>
        <input type="password" name="clave" required maxlength="100">

        <label>ID empleado</label>
        <input type="number" name="idEmpleado" required min="1">

        <label>Tipo de usuario</label>
        <select name="tipoUsuario" required>
            <option value="Administrador">Administrador</option>
            <option value="Usuario">Usuario</option>
            <option value="Recepcionista">Recepcionista</option>
        </select>

        <button type="submit">Registrar</button>
        <a class="enlace" href="usuarios">Cancelar</a>
    </form>
</main>
</body>
</html>
