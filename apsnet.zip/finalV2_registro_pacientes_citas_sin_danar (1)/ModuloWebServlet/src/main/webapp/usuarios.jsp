<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ page import="java.util.List" %>
<%@ page import="co.edu.sena.clinica.modelo.Usuario" %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <title>Usuarios - Clínica</title>
    <link rel="stylesheet" href="css/estilos.css">
</head>
<body>
<main class="contenedor">
    <h1>Gestión de usuarios</h1>

    <% String mensaje = (String) request.getAttribute("mensaje"); %>
    <% if (mensaje != null && !mensaje.isBlank()) { %>
        <div class="mensaje"><%= mensaje %></div>
    <% } %>

    <p><a class="boton" href="usuarios?accion=nuevo">Registrar usuario</a></p>

    <table>
        <thead>
        <tr>
            <th>ID</th>
            <th>Usuario</th>
            <th>Tipo</th>
            <th>Estado</th>
            <th>Acción</th>
        </tr>
        </thead>
        <tbody>
        <%
            List<Usuario> usuarios = (List<Usuario>) request.getAttribute("usuarios");
            if (usuarios != null) {
                for (Usuario usuario : usuarios) {
        %>
        <tr>
            <td><%= usuario.getIdUsuario() %></td>
            <td><%= usuario.getUsuario() %></td>
            <td><%= usuario.getTipoUsuario() %></td>
            <td><%= usuario.isEstado() ? "Activo" : "Inactivo" %></td>
            <td>
                <a href="usuarios?accion=eliminar&id=<%= usuario.getIdUsuario() %>"
                   onclick="return confirm('¿Desea eliminar este usuario?');">Eliminar</a>
            </td>
        </tr>
        <%
                }
            }
        %>
        </tbody>
    </table>

    <p><a href="index.html">Inicio</a></p>
</main>
</body>
</html>
