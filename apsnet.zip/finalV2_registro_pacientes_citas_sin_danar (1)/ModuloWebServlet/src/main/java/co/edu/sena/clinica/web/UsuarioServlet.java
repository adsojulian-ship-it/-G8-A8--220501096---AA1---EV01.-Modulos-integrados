package co.edu.sena.clinica.web;

import co.edu.sena.clinica.dao.UsuarioDAO;
import co.edu.sena.clinica.modelo.Usuario;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;

/**
 * Controlador web del módulo de usuarios.
 * GET: consulta, formulario, edición y eliminación.
 * POST: inserción y actualización desde formularios HTML.
 */
@WebServlet("/usuarios")
public class UsuarioServlet extends HttpServlet {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String accion = request.getParameter("accion");

        try {
            if ("nuevo".equalsIgnoreCase(accion)) {
                request.setAttribute("usuario", new Usuario());
                request.setAttribute("modoEdicion", false);
                request.getRequestDispatcher("/usuario-form.jsp").forward(request, response);
                return;
            }

            if ("eliminar".equalsIgnoreCase(accion)) {
                int idUsuario = Integer.parseInt(request.getParameter("id"));
                usuarioDAO.eliminar(idUsuario);
                response.sendRedirect(request.getContextPath() + "/usuarios?mensaje=Usuario eliminado correctamente");
                return;
            }

            listarUsuarios(request, response);
        } catch (NumberFormatException | SQLException ex) {
            mostrarError(request, response, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");

        try {
            String accion = request.getParameter("accion");
            Usuario usuario = construirUsuario(request);

            boolean resultado;
            String mensaje;

            if ("actualizar".equalsIgnoreCase(accion)) {
                usuario.setIdUsuario(Integer.parseInt(request.getParameter("idUsuario")));
                resultado = usuarioDAO.actualizar(usuario);
                mensaje = resultado ? "Usuario actualizado correctamente" : "No fue posible actualizar el usuario";
            } else {
                resultado = usuarioDAO.insertar(usuario);
                mensaje = resultado ? "Usuario registrado correctamente" : "No fue posible registrar el usuario";
            }

            response.sendRedirect(request.getContextPath() + "/usuarios?mensaje="
                    + java.net.URLEncoder.encode(mensaje, java.nio.charset.StandardCharsets.UTF_8));

        } catch (NumberFormatException | SQLException ex) {
            mostrarError(request, response, ex);
        }
    }

    private Usuario construirUsuario(HttpServletRequest request) {
        Usuario usuario = new Usuario();
        usuario.setUsuario(request.getParameter("usuario"));
        usuario.setClave(request.getParameter("clave"));
        usuario.setIdEmpleado(Integer.parseInt(request.getParameter("idEmpleado")));
        usuario.setTipoUsuario(request.getParameter("tipoUsuario"));
        usuario.setEstado(true);
        return usuario;
    }

    private void listarUsuarios(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, SQLException {
        request.setAttribute("usuarios", usuarioDAO.consultar());
        request.setAttribute("mensaje", request.getParameter("mensaje"));
        RequestDispatcher dispatcher = request.getRequestDispatcher("/usuarios.jsp");
        dispatcher.forward(request, response);
    }

    private void mostrarError(HttpServletRequest request, HttpServletResponse response, Exception ex)
            throws ServletException, IOException {
        request.setAttribute("mensajeError", "Error al procesar la solicitud: " + ex.getMessage());
        request.getRequestDispatcher("/error.jsp").forward(request, response);
    }
}
