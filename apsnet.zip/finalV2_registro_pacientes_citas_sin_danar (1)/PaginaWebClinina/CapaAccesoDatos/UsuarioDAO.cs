﻿using CapaEntidades;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaAccesoDatos
{
    public class UsuarioDAO
    {
        #region "PATRON SINGLETON"
        private static UsuarioDAO obj = null;
        private UsuarioDAO() { }
        public static UsuarioDAO getInstance()
        {
            if (obj == null)
            {
                obj = new UsuarioDAO();
            }
            return obj;
        }
        #endregion

        public bool Actualizar(Usuario obj)
        {
            bool ok = false;
            SqlConnection conexion = null;
            SqlCommand cmd = null;
            try
            {
                conexion = Conexion.getInstance().ConexionBD();
                cmd = new SqlCommand("spActualizarDatosUsuario", conexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@prmIdUsuario", obj.IdUsuario);
                cmd.Parameters.AddWithValue("@prmUsuario", obj.user);
                cmd.Parameters.AddWithValue("@prmClave", obj.password);
                cmd.Parameters.AddWithValue("@prmTipUser", obj.TipUser);

                conexion.Open();

                cmd.ExecuteNonQuery();

                ok = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return ok;
        }

        public Usuario AccesoSistema(string user, string pass)
        {
            SqlConnection conexion = null;
            SqlCommand cmd = null;
            Usuario obj= null;
            SqlDataReader dr = null;
            try
            {
                conexion = Conexion.getInstance().ConexionBD();
                cmd = new SqlCommand("spAccesoSistemaUsuario", conexion);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@prmUser", user);
                cmd.Parameters.AddWithValue("@prmPass", pass);
                conexion.Open();
                dr = cmd.ExecuteReader();
                if (dr.Read())
                {
                    obj = new Usuario();
                    obj.IdUsuario= Convert.ToInt32(dr["idUsuario"].ToString());
                    obj.user = dr["usuario"].ToString();
                    obj.password = dr["clave"].ToString();
                    obj.Nombre = dr["nombres"].ToString();
                    obj.ApPaterno = dr["apPaterno"].ToString();
                    obj.ApMaterno = dr["apMaterno"].ToString();
                    // Cargar el rol devuelto por el procedimiento de acceso.
                    // Si la columna no viene en el resultado, no impedir el inicio de sesión.
                    try { obj.TipUser = dr["tipoUser"].ToString(); }
                    catch (IndexOutOfRangeException) { obj.TipUser = ""; }
                    obj.ID =Convert.ToInt32( dr["idEmpleado"]);
                    obj.estado = true;
                   
                }
            }
            catch (Exception ex)
            {
                obj = null;
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return obj;
        }

        public bool RegistrarUsuario(Usuario obj)
        {
            SqlConnection con = null;
            SqlCommand cmd = null;
            bool response = false;
            try
            {
                con = Conexion.getInstance().ConexionBD();
                cmd = new SqlCommand("spRegistrarUsuario", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@prmUsuario", obj.user);
                cmd.Parameters.AddWithValue("@prmClave", obj.password);
                cmd.Parameters.AddWithValue("@prmIdEmpleado", obj.ID);
                cmd.Parameters.AddWithValue("@prmTipUser", obj.TipUser);
                cmd.Parameters.AddWithValue("@prmEstado", obj.estado);
                con.Open();

                int filas = cmd.ExecuteNonQuery();
                if (filas > 0) response = true;

            }
            catch (Exception ex)
            {
                response = false;
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return response;
        }


        // Registra una cuenta pública de invitado y su persona asociada en las tablas existentes.
        public bool RegistrarInvitado(string nombre, string dni, string usuario, string clave)
        {
            using (SqlConnection con = Conexion.getInstance().ConexionBD())
            {
                con.Open();
                using (SqlTransaction tx = con.BeginTransaction())
                {
                    try
                    {
                        using (SqlCommand verificar = new SqlCommand(
                            @"IF EXISTS (SELECT 1 FROM Usuario WHERE usuario=@usuario AND estado=1)
                                  OR EXISTS (SELECT 1 FROM Empleado WHERE nroDocumento=@dni AND estado=1)
                              SELECT 1 ELSE SELECT 0", con, tx))
                        {
                            verificar.Parameters.Add("@usuario", SqlDbType.VarChar, 50).Value = usuario;
                            verificar.Parameters.Add("@dni", SqlDbType.VarChar, 8).Value = dni;
                            if (Convert.ToInt32(verificar.ExecuteScalar()) == 1)
                                throw new InvalidOperationException("El nombre de usuario o documento ya está registrado.");
                        }

                        int idTipoEmpleado;
                        using (SqlCommand tipo = new SqlCommand("SELECT MIN(idTipoEmpleado) FROM TipoEmpleado", con, tx))
                        {
                            object valor = tipo.ExecuteScalar();
                            if (valor == null || valor == DBNull.Value)
                                throw new InvalidOperationException("No hay tipos de empleado configurados en la base de datos.");
                            idTipoEmpleado = Convert.ToInt32(valor);
                        }

                        int idEmpleado;
                        using (SqlCommand insertarPersona = new SqlCommand(@"
                            INSERT INTO Empleado
                                (idTipoEmpleado, nombres, apPaterno, apMaterno, nroDocumento, estado, imagen, usuario, clave)
                            VALUES
                                (@tipo, @nombre, '', '', @dni, 1, '', @usuario, @clave);
                            SELECT CAST(SCOPE_IDENTITY() AS INT);", con, tx))
                        {
                            insertarPersona.Parameters.Add("@tipo", SqlDbType.Int).Value = idTipoEmpleado;
                            insertarPersona.Parameters.Add("@nombre", SqlDbType.VarChar, 50).Value = nombre;
                            insertarPersona.Parameters.Add("@dni", SqlDbType.VarChar, 8).Value = dni;
                            insertarPersona.Parameters.Add("@usuario", SqlDbType.VarChar, 50).Value = usuario;
                            insertarPersona.Parameters.Add("@clave", SqlDbType.VarChar, 50).Value = clave;
                            idEmpleado = Convert.ToInt32(insertarPersona.ExecuteScalar());
                        }

                        using (SqlCommand insertarUsuario = new SqlCommand(@"
                            INSERT INTO Usuario (usuario, clave, estado, idEmpleado, tipoUser)
                            VALUES (@usuario, @clave, 1, @idEmpleado, 'Invitado');", con, tx))
                        {
                            insertarUsuario.Parameters.Add("@usuario", SqlDbType.VarChar, 50).Value = usuario;
                            insertarUsuario.Parameters.Add("@clave", SqlDbType.VarChar, 50).Value = clave;
                            insertarUsuario.Parameters.Add("@idEmpleado", SqlDbType.Int).Value = idEmpleado;
                            insertarUsuario.ExecuteNonQuery();
                        }

                        // Vincular también la cuenta con un paciente para que pueda
                        // reservar y consultar citas por número de documento.
                        using (SqlCommand existePaciente = new SqlCommand(
                            "SELECT COUNT(1) FROM Paciente WHERE nroDocumento = @dni", con, tx))
                        {
                            existePaciente.Parameters.Add("@dni", SqlDbType.VarChar, 8).Value = dni;
                            int cantidad = Convert.ToInt32(existePaciente.ExecuteScalar());
                            if (cantidad == 0)
                            {
                                // El formulario público solo solicita nombre y documento.
                                // Se separa el nombre cuando es posible; los demás datos
                                // quedan neutros hasta que se completen en Registro de Pacientes.
                                string[] partesNombre = (nombre ?? "").Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                                string nombres = nombre;
                                string apellidoPaterno = "";
                                string apellidoMaterno = "";
                                if (partesNombre.Length == 2)
                                {
                                    nombres = partesNombre[0];
                                    apellidoPaterno = partesNombre[1];
                                }
                                else if (partesNombre.Length >= 3)
                                {
                                    nombres = string.Join(" ", partesNombre, 0, partesNombre.Length - 2);
                                    apellidoPaterno = partesNombre[partesNombre.Length - 2];
                                    apellidoMaterno = partesNombre[partesNombre.Length - 1];
                                }

                                using (SqlCommand insertarPaciente = new SqlCommand("spRegistrarPaciente", con, tx))
                                {
                                    insertarPaciente.CommandType = CommandType.StoredProcedure;
                                    insertarPaciente.Parameters.AddWithValue("@prmNombres", nombres);
                                    insertarPaciente.Parameters.AddWithValue("@prmApPaterno", apellidoPaterno);
                                    insertarPaciente.Parameters.AddWithValue("@prmApMaterno", apellidoMaterno);
                                    insertarPaciente.Parameters.AddWithValue("@prmEdad", 0);
                                    insertarPaciente.Parameters.AddWithValue("@prmSexo", 'M');
                                    insertarPaciente.Parameters.AddWithValue("@prmNroDoc", dni);
                                    insertarPaciente.Parameters.AddWithValue("@prmDireccion", "");
                                    insertarPaciente.Parameters.AddWithValue("@prmTelefono", "");
                                    insertarPaciente.Parameters.AddWithValue("@prmEstado", true);
                                    insertarPaciente.ExecuteNonQuery();
                                }
                            }
                        }

                        tx.Commit();
                        return true;
                    }
                    catch
                    {
                        try { tx.Rollback(); } catch { }
                        throw;
                    }
                }
            }
        }

        public List<Usuario> ListarUsuarios()
        {
            List<Usuario> Lista = new List<Usuario>();
            SqlConnection con = null;
            SqlCommand cmd = null;
            SqlDataReader dr = null;

            try
            {
                con = Conexion.getInstance().ConexionBD();
                cmd = new SqlCommand("spListarUsuarios", con);
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                dr = cmd.ExecuteReader();

                while (dr.Read())
                {
                    // Crear objetos de tipo Usuario
                    Usuario obj = new Usuario();
                    obj.IdUsuario = Convert.ToInt32(dr["idUsuario"].ToString());
                    obj.Nombre = dr["nombres"].ToString();
                    obj.ApPaterno = dr["apPaterno"].ToString();
                    obj.ApMaterno = dr["apMaterno"].ToString();
                    obj.user = dr["usuario"].ToString();
                    obj.password = dr["clave"].ToString();
                    obj.NroDocumento = (dr["nroDocumento"].ToString());
                    obj.TipUser = dr["tipoUser"].ToString();
                    obj.Estado = true;


                    //añadir a la lista de objetos
                    Lista.Add(obj);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                con.Close();
            }
            return Lista;
        }

        public bool Eliminar(int id)
        {
            SqlConnection conexion = null;
            SqlCommand cmd = null;
            bool ok = false;
            try
            {
                conexion = Conexion.getInstance().ConexionBD();
                cmd = new SqlCommand("spEliminarUsuario", conexion);
                cmd.Parameters.AddWithValue("@prmIdUsuario", id);
                cmd.CommandType = CommandType.StoredProcedure;

                conexion.Open();

                cmd.ExecuteNonQuery();

                ok = true;

            }
            catch (Exception ex)
            {
                ok = false;
                throw ex;
            }
            finally
            {
                conexion.Close();
            }
            return ok;
        }
    }
}
