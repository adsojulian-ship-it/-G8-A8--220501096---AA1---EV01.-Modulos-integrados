﻿using CapaEntidades;
using CapaLogicaNegocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PaginaWebClinina
{
    public partial class GestionarReservaCitas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                LlenarEspecialidades();
            }

        }


        private void LlenarGridViewHorariosAtencion()
        {

            //if (txtFechaAtencion.Text.Equals(string.Empty))
            //{
            //    Response.Write("<script>alert('No ha ingresado una fecha valida')</script>");
            //    return;
            //}
            //// obtenemos fecha
            //String fecha = txtFechaAtencion.Text;
            //DateTime fechaBusqueda = Convert.ToDateTime(fecha);

            // obtenemos el idEspecialidad
            Int32 idEspecialidad = Convert.ToInt32(ddlEspecialidad.SelectedValue);

            List<HorarioAtencion> Lista = HorarioAtencionLN.getInstance().ListarHorario(idEspecialidad);
            grdHorariosAtencion.DataSource = Lista;
            grdHorariosAtencion.DataBind();
        }

        private void LlenarEspecialidades()
        {
            List<Especialidad> Lista = EspecialidadLN.getInstance().Listar();

            ddlEspecialidad.DataSource = Lista;
            ddlEspecialidad.DataValueField = "IdEspecialidad";
            ddlEspecialidad.DataTextField = "Descripcion";
            ddlEspecialidad.DataBind();
        }

        [WebMethod]
        public static Paciente BuscarPacienteDNI(String dni)
        {
            return PacienteLN.getInstance().BuscarPacienteDNI(dni);
        }

        // Busca un paciente ya registrado para reutilizarlo al reservar una cita.
        protected void btnBuscar_Click(object sender, EventArgs e)
        {
            string dni = (txtDNI.Text ?? string.Empty).Trim();

            if (string.IsNullOrWhiteSpace(dni))
            {
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "DniVacio",
                    "alert('Ingrese el DNI del paciente.');", true);
                LimpiarDatosPaciente();
                return;
            }

            Paciente paciente = PacienteLN.getInstance().BuscarPacienteDNI(dni);
            if (paciente == null)
            {
                LimpiarDatosPaciente();
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "PacienteNoEncontrado",
                    "alert('No se encontró un paciente con ese DNI. Registre el paciente primero.');", true);
                return;
            }

            idPaciente.Value = paciente.IdPaciente.ToString();
            txtNombres.Text = paciente.Nombres;
            txtApellidos.Text = (paciente.ApPaterno + " " + paciente.ApMaterno).Trim();
            txtTelefono.Text = paciente.Telefono;
            txtEdad.Text = paciente.Edad.ToString();
            txtSexo.Text = paciente.Sexo == 'F' ? "Femenino" : "Masculino";
        }

        private void LimpiarDatosPaciente()
        {
            idPaciente.Value = string.Empty;
            txtNombres.Text = string.Empty;
            txtApellidos.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtEdad.Text = string.Empty;
            txtSexo.Text = string.Empty;
        }

        protected void btnBuscarHorario_Click(object sender, EventArgs e)
        {
            try
            {
                int idEspecialidad = Convert.ToInt32(ddlEspecialidad.SelectedValue);
                List<HorarioAtencion> horarios = HorarioAtencionLN.getInstance().ListarHorario(idEspecialidad)
                    ?? new List<HorarioAtencion>();

                // Siempre revisar mañana, aunque existan horarios en otras fechas.
                // Si mañana no hay un horario libre, crear uno automáticamente.
                DateTime fechaObjetivo = DateTime.Today.AddDays(1);
                bool hayHorarioManana = horarios.Any(h => h.Fecha.Date == fechaObjetivo.Date);

                List<Cita> citas = CitaLN.getInstance().ListarCitas() ?? new List<Cita>();
                if (!hayHorarioManana)
                {
                    CrearHorarioAutomatico(idEspecialidad, horarios, citas);
                    horarios = HorarioAtencionLN.getInstance().ListarHorario(idEspecialidad)
                        ?? new List<HorarioAtencion>();
                }

                grdHorariosAtencion.DataSource = horarios;
                grdHorariosAtencion.DataBind();

                if (!horarios.Any(h => h.Fecha.Date >= DateTime.Today))
                {
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "SinHorarioAutomatico",
                        "alert('No fue posible crear un horario automático. Verifique la base de datos y los procedimientos almacenados.');", true);
                }
            }
            catch (Exception)
            {
                ScriptManager.RegisterStartupScript(Page, Page.GetType(), "ErrorBuscarHorario",
                    "alert('No fue posible consultar o crear el horario. Verifique la base de datos e inténtelo nuevamente.');", true);
            }
        }

        private void CrearHorarioAutomatico(int idEspecialidad, List<HorarioAtencion> horarios, List<Cita> citas)
        {
            // Documento ficticio estable por especialidad: reutilizarlo para no duplicar médicos NN.
            string documentoFicticio = "99" + idEspecialidad.ToString("D6");
            List<Medico> medicos = MedicoLN.getInstance().ListarMedicos() ?? new List<Medico>();
            Medico medicoAutomatico = medicos.FirstOrDefault(m =>
                string.Equals((m.NroDocumento ?? string.Empty).Trim(), documentoFicticio, StringComparison.OrdinalIgnoreCase));

            // Usar primero un médico existente de la especialidad.
            if (medicoAutomatico == null)
            {
                string especialidadSeleccionada = (ddlEspecialidad.SelectedItem.Text ?? string.Empty).Trim();
                medicoAutomatico = medicos.FirstOrDefault(m => m.Especialidad != null &&
                    string.Equals((m.Especialidad.Descripcion ?? string.Empty).Trim(),
                                  especialidadSeleccionada, StringComparison.OrdinalIgnoreCase));
            }

            // Crear NN únicamente si no hay un médico existente para esta especialidad.
            if (medicoAutomatico == null)
            {
                Medico nuevo = new Medico();
                nuevo.IdMedico = 0;
                nuevo.RTipoEmpleado.ID = 1002;
                nuevo.Nombre = "NN";
                nuevo.ApPaterno = "NN";
                nuevo.ApMaterno = "NN";
                nuevo.NroDocumento = documentoFicticio;
                nuevo.Especialidad = new Especialidad { IdEspecialidad = idEspecialidad };
                nuevo.Estado = true;

                MedicoLN.getInstance().RegistrarMedico(nuevo);
                medicos = MedicoLN.getInstance().ListarMedicos() ?? new List<Medico>();
                medicoAutomatico = medicos.FirstOrDefault(m =>
                    string.Equals((m.NroDocumento ?? string.Empty).Trim(), documentoFicticio, StringComparison.OrdinalIgnoreCase));
            }

            if (medicoAutomatico == null || medicoAutomatico.IdMedico <= 0)
                throw new InvalidOperationException("No se pudo recuperar el médico existente o automático.");

            // Elegir mañana a partir de las 09:00. Si ya hay turnos/citas, avanzar una hora
            // después de la última ocupada (por ejemplo, 20:00 -> 21:00). Si se agotó el día,
            // pasar al siguiente día a las 09:00.
            DateTime fechaAutomatica = DateTime.Today.AddDays(1);
            List<string> horasOcupadas = new List<string>();

            foreach (HorarioAtencion h in horarios)
            {
                if (h.Fecha.Date == fechaAutomatica.Date && h.Hora != null &&
                    h.Medico != null && h.Medico.IdMedico == medicoAutomatico.IdMedico)
                    horasOcupadas.Add((h.Hora.hora ?? string.Empty).Trim());
            }
            foreach (Cita c in citas)
            {
                if (c.FechaReserva.Date == fechaAutomatica.Date && c.Medico != null &&
                    c.Medico.IdMedico == medicoAutomatico.IdMedico)
                    horasOcupadas.Add((c.Hora ?? string.Empty).Trim());
            }

            TimeSpan horaAutomatica = new TimeSpan(9, 0, 0);
            if (horasOcupadas.Count > 0)
            {
                TimeSpan ultimaHora;
                if (TimeSpan.TryParse(horasOcupadas.OrderBy(x =>
                    TimeSpan.TryParse(x, out TimeSpan t) ? t : TimeSpan.Zero).Last(), out ultimaHora))
                {
                    horaAutomatica = ultimaHora.Add(TimeSpan.FromHours(1));
                }
            }

            if (horaAutomatica >= new TimeSpan(22, 0, 0))
            {
                fechaAutomatica = fechaAutomatica.AddDays(1);
                horaAutomatica = new TimeSpan(9, 0, 0);
            }

            // Si el turno calculado ya existe para ese médico, avanzar hasta encontrar uno libre.
            while (horarios.Any(h => h.Fecha.Date == fechaAutomatica.Date &&
                       h.Medico != null && h.Medico.IdMedico == medicoAutomatico.IdMedico &&
                       h.Hora != null && string.Equals(h.Hora.hora.Trim(), horaAutomatica.ToString(@"hh\:mm"),
                           StringComparison.OrdinalIgnoreCase)) ||
                   citas.Any(c => c.FechaReserva.Date == fechaAutomatica.Date &&
                       c.Medico != null && c.Medico.IdMedico == medicoAutomatico.IdMedico &&
                       string.Equals((c.Hora ?? "").Trim(), horaAutomatica.ToString(@"hh\:mm"),
                           StringComparison.OrdinalIgnoreCase)))
            {
                horaAutomatica = horaAutomatica.Add(TimeSpan.FromHours(1));
                if (horaAutomatica >= new TimeSpan(22, 0, 0))
                {
                    fechaAutomatica = fechaAutomatica.AddDays(1);
                    horaAutomatica = new TimeSpan(9, 0, 0);
                }
            }

            HorarioAtencion horarioCreado = HorarioAtencionLN.getInstance().RegistrarHorarioAtencion(
                new HorarioAtencion
                {
                    Medico = new Medico { IdMedico = medicoAutomatico.IdMedico },
                    Hora = new Hora { hora = horaAutomatica.ToString(@"hh\:mm") },
                    Fecha = fechaAutomatica,
                    Estado = true
                });

            if (horarioCreado == null)
                throw new InvalidOperationException("No se pudo registrar el horario automático.");

            ScriptManager.RegisterStartupScript(Page, Page.GetType(), "HorarioCreadoAutomatico",
                "alert('Se generó un horario automáticamente para el " +
                fechaAutomatica.ToString("dd/MM/yyyy") + " a las " +
                horaAutomatica.ToString(@"hh\:mm") + ".');", true);
        }

        [WebMethod]
        public static bool ActualizarHorarioAtencion(String id)
        {
            HorarioAtencion obj = new HorarioAtencion()
            {
                IdHorarioAtencion = Convert.ToInt32(id),
            };

            bool ok = HorarioAtencionLN.getInstance().Actualizar(obj);
            return ok;
        }


        protected void btnReservarCita_Click(object sender, EventArgs e)
        {
            // ejecutar el guardado de la reserva
            bool isSelected = HorarioAtencionSelccionado();

            if (!idPaciente.Value.Equals(string.Empty) && isSelected.Equals(true))
            {
                Cita objCita = ObtenerCitaSeleccionada();
                bool response = CitaLN.getInstance().RegistrarCita(objCita);

                if (response)
                {
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Mensaje", "<script>alert('Cita registrada correctamente.')</script>", false);
                    Response.Redirect("GestionarReservaCitas.aspx");
                }
                else
                {
                    ScriptManager.RegisterStartupScript(Page, Page.GetType(), "Alerta", "<script>alert('Error al registrar la cita.')</script>", false);
                }

            }
           
        }

        //Comprobar si existe un horario seleccionado
        private bool HorarioAtencionSelccionado()
        {
            foreach (GridViewRow row in grdHorariosAtencion.Rows)
            {
                CheckBox chkHorario = (row.FindControl("chkSeleccionar") as CheckBox);

                if (chkHorario.Checked)
                {
                    return true;
                }
            }
            return false;
        }


        //Obtener el objeto cita
        private Cita ObtenerCitaSeleccionada()
        {
            Cita objCita = new Cita();

            foreach (GridViewRow row in grdHorariosAtencion.Rows)
            {
                CheckBox chkHorario = (row.FindControl("chkSeleccionar") as CheckBox);

                if (chkHorario.Checked)
                {
                    objCita.Hora = (row.FindControl("lblHora") as Label).Text;
                    String fecha = (row.FindControl("lblFecha") as Label).Text;
                    objCita.FechaReserva = Convert.ToDateTime(fecha);
                    objCita.Paciente.IdPaciente = Convert.ToInt32(idPaciente.Value);

                    string idMedico = (row.FindControl("hfIdMedico") as HiddenField).Value;
                    objCita.Medico.IdMedico = Convert.ToInt32(idMedico);

                    
                  //  string idMedico = (row.FindControl("hfIdMedico") as HiddenField).Value;

                    break;
                }
            }
            return objCita;
        }

        protected void btnAgregarHorario_Click(object sender, EventArgs e)
        {
            Response.Redirect("GestionarHorarioAtencion.aspx");
        }
    }
}