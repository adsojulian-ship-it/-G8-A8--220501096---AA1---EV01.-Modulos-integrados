<%@ Page Title="" Language="C#" MasterPageFile="~/Home.Master" AutoEventWireup="true" CodeBehind="PanelGeneral.aspx.cs" Inherits="PaginaWebClinina.PanelGeneral" %>
<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
    <!-- PANEL GENERAL: presentación visual, sin cambiar la lógica -->
    <style>
        .cjs-dashboard-intro{
            max-width:1154px;margin:0 auto 16px;display:flex;
            align-items:center;justify-content:space-between;gap:15px;
            background:#fff;border:1px solid #e4eaf0;border-radius:12px;
            padding:15px 18px;box-shadow:0 5px 18px rgba(32,64,86,.05);
        }
        .cjs-dashboard-intro h2{margin:0 0 4px;color:#243447;font-size:18px;font-weight:700;}
        .cjs-dashboard-intro p{margin:0;color:#718096;font-size:12px;}
        .cjs-status{
            display:inline-flex;align-items:center;gap:6px;color:#278a43;
            background:#edf9f0;border:1px solid #d5f0dc;padding:7px 11px;
            border-radius:20px;font-size:11px;white-space:nowrap;
        }
        .cjs-status i{font-size:8px;}
        @media(max-width:600px){.cjs-dashboard-intro{align-items:flex-start;flex-direction:column;}}
    </style>
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="ContentPlaceHolder1" runat="server">
    <!-- CONTENIDO ORIGINAL: se conserva la imagen del panel -->
    <div class="cjs-dashboard-intro">
        <div>
            <h2>Panel de Administración</h2>
            <p>Gestiona pacientes, citas, horarios y servicios de la clínica.</p>
        </div>
        <span class="cjs-status"><i class="fa fa-circle"></i> Sistema activo</span>
    </div>

    <img src="img/imgpanelgeneral.jpg" alt="Panel general API CJS SENA" />
</asp:Content>
