﻿//------------------------------------------------------------------------------
// <generado automáticamente>
//     Este código fue generado por una herramienta.
//
//     Los cambios en este archivo podrían causar un comportamiento incorrecto y se perderán si
//     se vuelve a generar el código. 
// </generado automáticamente>
//------------------------------------------------------------------------------

namespace PaginaWebClinina
{


    public partial class login
    {

        /// <summary>
        /// Control form1.
        /// </summary>
        /// <remarks>
        /// Campo generado automáticamente.
        /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
        /// </remarks>
        protected global::System.Web.UI.HtmlControls.HtmlForm form1;

        /// <summary>
        /// Control LoginUser.
        /// </summary>
        /// <remarks>
        /// Campo generado automáticamente.
        /// Para modificarlo, mueva la declaración del campo del archivo del diseñador al archivo de código subyacente.
        /// </remarks>
        protected global::System.Web.UI.WebControls.Login LoginUser;

        protected global::System.Web.UI.WebControls.Label lblRegistro;
        protected global::System.Web.UI.WebControls.TextBox txtRegNombre;
        protected global::System.Web.UI.WebControls.TextBox txtRegDni;
        protected global::System.Web.UI.WebControls.TextBox txtRegUsuario;
        protected global::System.Web.UI.WebControls.TextBox txtRegClave;
        protected global::System.Web.UI.WebControls.Button btnRegistrarInvitado;
    }
}
