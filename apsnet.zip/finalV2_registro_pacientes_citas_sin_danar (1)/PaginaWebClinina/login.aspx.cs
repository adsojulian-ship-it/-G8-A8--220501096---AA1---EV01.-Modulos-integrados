﻿using CapaEntidades;
using CapaLogicaNegocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using CapaPresentacion.Custom;

namespace PaginaWebClinina
{
    public partial class login : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                Session["UserSessionId"] = null;
            }

        }


        protected void btnRegistrarInvitado_Click(object sender, EventArgs e)
        {
            string nombre = (txtRegNombre.Text ?? "").Trim();
            string dni = (txtRegDni.Text ?? "").Trim();
            string usuario = (txtRegUsuario.Text ?? "").Trim();
            string clave = txtRegClave.Text ?? "";

            if (string.IsNullOrWhiteSpace(nombre) ||
                string.IsNullOrWhiteSpace(dni) ||
                string.IsNullOrWhiteSpace(usuario) ||
                string.IsNullOrWhiteSpace(clave))
            {
                MostrarMensajeRegistro("Complete todos los campos para crear su cuenta.", false);
                return;
            }

            if (nombre.Length > 50 || usuario.Length > 50 || clave.Length > 50 ||
                dni.Length > 8 || !dni.All(char.IsDigit))
            {
                MostrarMensajeRegistro("Revise los datos: el documento debe tener hasta 8 dígitos y los demás campos no deben superar el límite indicado.", false);
                return;
            }

            try
            {
                UsuarioLN.getInstance().RegistrarInvitado(nombre, dni, usuario, clave);
                txtRegNombre.Text = "";
                txtRegDni.Text = "";
                txtRegUsuario.Text = "";
                txtRegClave.Text = "";
                MostrarMensajeRegistro("Cuenta creada correctamente. Ya puede iniciar sesión. El usuario quedó registrado como Invitado y aparecerá en el listado del administrador.", true);
            }
            catch (InvalidOperationException ex)
            {
                MostrarMensajeRegistro(ex.Message, false);
            }
            catch (Exception)
            {
                MostrarMensajeRegistro("No fue posible registrar la cuenta. Verifique la conexión con SQL Server y que la base de datos tenga configurados los tipos de empleado.", false);
            }
        }

        private void MostrarMensajeRegistro(string mensaje, bool correcto)
        {
            lblRegistro.Text = Server.HtmlEncode(mensaje);
            lblRegistro.ForeColor = correcto ? System.Drawing.Color.Green : System.Drawing.Color.Firebrick;
            lblRegistro.CssClass = "help-block";
        }

        protected void LoginUser_Authenticate(object sender, AuthenticateEventArgs e)
        {
            bool auth = Membership.ValidateUser(LoginUser.UserName, LoginUser.Password);

            if (auth)
            {
                // Empleado objEmpleado = EmpleadoLN.getInstance().AccesoSistema(LoginUser.UserName, LoginUser.Password);
                Usuario obj = UsuarioLN.getInstance().AccesoSistema(LoginUser.UserName, LoginUser.Password);
                if (obj != null)
                {
                    SessionManager _SessionManager = new SessionManager(Session);
                    //SessionManager.UserSessionId = objEmpleado.ID.ToString();
                    _SessionManager.UserSessionEmpleado = obj;
                    FormsAuthentication.RedirectFromLoginPage(LoginUser.UserName, false);
                }
                else
                {
                    Response.Write("<script>alert('USUARIO INCORRECTO.')</script>");
                }
            }
            else
            {
                Response.Write("<script>alert('DATOS INCORRECTOS')</script>");
            }
        }
    }
}