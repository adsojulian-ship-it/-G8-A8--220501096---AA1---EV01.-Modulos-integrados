﻿using CapaEntidades;
using CapaLogicaNegocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Script.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PaginaWebClinina
{
    public partial class GestionarUsuario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        [WebMethod]
        public static List<Usuario> ListarUsuarios()
        {
            List<Usuario> Lista = null;
            try
            {
                Lista = UsuarioLN.getInstance().ListarUsuarios();
            }
            catch (Exception)
            {
                Lista = new List<Usuario>();
            }
            return Lista;
        }

        [WebMethod]
        public static bool EliminarDatosUsuario(String id)
        {
            Int32 idUsuario = Convert.ToInt32(id);

            bool ok = UsuarioLN.getInstance().Eliminar(idUsuario);

            return ok;

        }

        private Usuario GetEntity()
        {
            Usuario obj = new Usuario();
            obj.IdUsuario = 0;
            obj.user = txtUsuario.Text;
            obj.password = txtContraseña.Text;
            obj.ID = Convert.ToInt32(idEmpleado.Value);
            obj.TipUser = ddlTipoUsuario.SelectedValue.ToString();
            obj.Estado = true;

            return obj;
        }

        private Usuario GetEntity2()
        {
            Usuario obj = new Usuario();
            obj.IdUsuario = Convert.ToInt32(idUsuario.Value); 
            obj.user = txtUsuario.Text;
            obj.password = txtContraseña.Text;
            obj.TipUser = ddlTipoUsuario.SelectedValue.ToString();
            obj.Estado = true;
            return obj;
        }

        protected void btnRegistrar_Click(object sender, EventArgs e)
        {
            Usuario obj = GetEntity();
            bool response = UsuarioLN.getInstance().RegistrarUsuario(obj);
            if (response)
            {
                Response.Write("<script>alert('Usuario registrado correctamente.')</script>");

            }
            else
            {
                Response.Write("<script>alert('REGISTRO INCORRECTO.')</script>");
            }
            Limpiar();
        }
         

        /// <summary>
        /// Registra un usuario desde Postman sin modificar la conexión existente a SQL Server.
        /// POST: GestionarUsuario.aspx/RegistrarUsuarioPostman
        /// Body JSON: { "usuario": "juan", "clave": "123", "idEmpleado": 1, "tipoUsuario": "Administrador" }
        /// </summary>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static object RegistrarUsuarioPostman(string usuario, string clave, int idEmpleado, string tipoUsuario)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(usuario))
                    return new { success = false, message = "El usuario es obligatorio." };

                if (string.IsNullOrWhiteSpace(clave))
                    return new { success = false, message = "La contraseña es obligatoria." };

                if (idEmpleado <= 0)
                    return new { success = false, message = "El idEmpleado debe ser mayor que cero." };

                if (string.IsNullOrWhiteSpace(tipoUsuario))
                    return new { success = false, message = "El tipo de usuario es obligatorio." };

                // Se utiliza exactamente la misma capa de negocio y el mismo acceso a SQL Server
                // que utiliza el formulario existente.
                Usuario obj = new Usuario();
                obj.IdUsuario = 0;
                obj.user = usuario.Trim();
                obj.password = clave;
                obj.ID = idEmpleado;
                obj.TipUser = tipoUsuario.Trim();
                obj.estado = true;
                obj.Estado = true;

                // Verifica si ya existe antes de registrar para evitar duplicados.
                List<Usuario> usuarios = UsuarioLN.getInstance().ListarUsuarios();
                Usuario existente = usuarios.FirstOrDefault(x =>
                    !string.IsNullOrWhiteSpace(x.user) &&
                    x.user.Equals(obj.user, StringComparison.OrdinalIgnoreCase));

                if (existente != null)
                {
                    return new
                    {
                        success = false,
                        message = "El usuario ya existe.",
                        usuario = existente.user,
                        idUsuario = existente.IdUsuario
                    };
                }

                bool registrado = UsuarioLN.getInstance().RegistrarUsuario(obj);

                return new
                {
                    success = registrado,
                    message = registrado
                        ? "Usuario registrado correctamente."
                        : "No fue posible registrar el usuario.",
                    usuario = obj.user
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    success = false,
                    message = "Error al registrar el usuario.",
                    detail = ex.Message
                };
            }
        }

        /// <summary>
        /// Lista los usuarios registrados para Postman, mostrando primero los más recientes.
        /// No devuelve contraseñas.
        /// POST: GestionarUsuario.aspx/ListarUsuariosPostman
        /// Body JSON: {}
        /// </summary>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static object ListarUsuariosPostman()
        {
            try
            {
                List<Usuario> usuarios = UsuarioLN.getInstance().ListarUsuarios();

                var resultado = usuarios
                    .OrderByDescending(x => x.IdUsuario)
                    .Select(x => new
                    {
                        idUsuario = x.IdUsuario,
                        usuario = x.user,
                        nombres = x.Nombre,
                        apPaterno = x.ApPaterno,
                        apMaterno = x.ApMaterno,
                        nroDocumento = x.NroDocumento,
                        tipoUsuario = x.TipUser,
                        estado = x.Estado
                    })
                    .ToList();

                return new
                {
                    success = true,
                    message = "Usuarios consultados correctamente.",
                    total = resultado.Count,
                    usuarios = resultado
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    success = false,
                    message = "Error al consultar los usuarios.",
                    detail = ex.Message
                };
            }
        }

        /// <summary>
        /// Busca un usuario desde Postman utilizando el mismo procedimiento que la aplicación.
        /// POST: GestionarUsuario.aspx/BuscarUsuarioPostman
        /// Body JSON: { "usuario": "juan" }
        /// </summary>
        [WebMethod]
        [ScriptMethod(ResponseFormat = ResponseFormat.Json)]
        public static object BuscarUsuarioPostman(string usuario)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(usuario))
                    return new { success = false, message = "El usuario es obligatorio." };

                List<Usuario> usuarios = UsuarioLN.getInstance().ListarUsuarios();
                Usuario encontrado = usuarios.FirstOrDefault(x =>
                    !string.IsNullOrWhiteSpace(x.user) &&
                    x.user.Equals(usuario.Trim(), StringComparison.OrdinalIgnoreCase));

                if (encontrado == null)
                {
                    return new
                    {
                        success = false,
                        message = "Usuario no encontrado."
                    };
                }

                return new
                {
                    success = true,
                    message = "Usuario encontrado correctamente.",
                    idUsuario = encontrado.IdUsuario,
                    usuario = encontrado.user,
                    nombres = encontrado.Nombre,
                    apPaterno = encontrado.ApPaterno,
                    apMaterno = encontrado.ApMaterno,
                    nroDocumento = encontrado.NroDocumento,
                    tipoUsuario = encontrado.TipUser,
                    estado = encontrado.Estado
                };
            }
            catch (Exception ex)
            {
                return new
                {
                    success = false,
                    message = "Error al buscar el usuario.",
                    detail = ex.Message
                };
            }
        }

        [WebMethod]
        public static Empleado BuscarEmpleadoDNI(String dni)
        {
            return EmpleadoLN.getInstance().BuscarEmpleado(dni);
        }

        private void Limpiar()
        {
            txtDNI.Text="";
            txtNombres.Text = "";
            txtApellidos.Text = "";
            txtUsuario.Text = "";
            txtContraseña.Text = "";
            ddlTipoUsuario.SelectedIndex = 0;
            txtTipoEmpleado.Text = "";
            idEmpleado.Value = "0";
        }

        protected void btnCancelar_Click(object sender, EventArgs e)
        {
            Limpiar();
        }

        protected void btnActualizar_Click(object sender, EventArgs e)
        {
            Usuario obj = GetEntity2();
            bool response = UsuarioLN.getInstance().Actualizar(obj);
            if (response)
            {
                Response.Write("<script>alert('ACTUALIZACION CORRECTA.')</script>");

            }
            else
            {
                Response.Write("<script>alert('ACTUALIZACION INCORRECTA.')</script>");
            }
            Limpiar();

        }
    }
}