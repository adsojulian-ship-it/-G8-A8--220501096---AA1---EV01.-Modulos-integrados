﻿using CapaPresentacion.Custom;
using CapaEntidades;
using CapaLogicaNegocio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Text.RegularExpressions;

namespace PaginaWebClinina
{
    public partial class PanelGeneral : BasePage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
            }
        }

        [WebMethod]
        public static bool Logout()
        {
            HttpContext.Current.Session.Clear();
            HttpContext.Current.Session.Abandon();
            return true;
        }

        // API interna del asistente. Usa las capas existentes del proyecto
        // para consultar y registrar datos, sin crear rutas nuevas.
        [WebMethod(EnableSession = true)]
        public static string AsistenteIA(string mensaje)
        {
            if (string.IsNullOrWhiteSpace(mensaje))
                return "Escríbeme lo que necesitas y te ayudo.";

            mensaje = mensaje.Trim();
            Usuario usuarioActual = HttpContext.Current.Session["UserSessionEmpleado"] as Usuario;
            if (usuarioActual == null)
                return "Debes iniciar sesión para utilizar las funciones de registro y citas.";

            if (EsCancelar(mensaje))
            {
                LimpiarAsistente();
                return "Listo. Cancelé la operación. ¿Qué necesitas hacer ahora?";
            }

            try
            {
                string flujo = Convert.ToString(HttpContext.Current.Session["Asistente_Flujo"]);
                // Crear usuarios sigue siendo exclusivo del administrador.
                // Pacientes, citas, médicos y enfermeras no se bloquean por este control general.
                if (flujo == "USUARIO" && !EsAdministradorActual())
                {
                    LimpiarAsistente();
                    return "La creación de usuarios está reservada al Administrador.";
                }

                if (flujo == "USUARIO") return ProcesarCrearUsuario(mensaje);
                if (flujo == "PACIENTE") return ProcesarCrearPaciente(mensaje);
                if (flujo == "MEDICO") return ProcesarCrearMedico(mensaje);
                if (flujo == "ENFERMERA") return ProcesarCrearEnfermera(mensaje);
                if (flujo == "CITA") return ProcesarCrearCita(mensaje);

                string normalizado = Normalizar(mensaje);

                if (Contiene(normalizado, "registrar paciente", "crear paciente", "nuevo paciente", "inscribir paciente"))
                {
                    HttpContext.Current.Session["Asistente_Flujo"] = "PACIENTE";
                    HttpContext.Current.Session["Asistente_Paso"] = "DNI";
                    return "Vamos a registrar al paciente en la base de datos del sistema. Primero dime su documento de identidad.";
                }

                if (Contiene(normalizado, "registrar medico", "registrar médico", "crear medico", "crear médico", "nuevo medico", "nuevo médico"))
                {
                    HttpContext.Current.Session["Asistente_Flujo"] = "MEDICO";
                    HttpContext.Current.Session["Asistente_Paso"] = "DNI";
                    return "Vamos a registrar un médico. Primero dime su documento de identidad.";
                }

                if (Contiene(normalizado, "registrar enfermera", "crear enfermera", "nueva enfermera", "registrar enfermero", "crear enfermero"))
                {
                    HttpContext.Current.Session["Asistente_Flujo"] = "ENFERMERA";
                    HttpContext.Current.Session["Asistente_Paso"] = "DNI";
                    return "Vamos a registrar una enfermera. Primero dime su documento de identidad.";
                }

                if (Contiene(normalizado, "crear usuario", "registrar usuario", "nuevo usuario", "crear una cuenta", "registrar una cuenta"))
                {
                    if (!EsAdministradorActual())
                        return "Tu cuenta no tiene autorización para crear usuarios. Esta función es exclusiva del Administrador.";
                    HttpContext.Current.Session["Asistente_Flujo"] = "USUARIO";
                    HttpContext.Current.Session["Asistente_Paso"] = "DNI";
                    return "Claro. Crearé el usuario asociado a un empleado que ya esté registrado. Dime el documento del empleado.";
                }

                if (Contiene(normalizado, "crear cita", "agendar cita", "reservar cita", "programar cita", "sacar cita", "pedir cita"))
                {
                    HttpContext.Current.Session["Asistente_Flujo"] = "CITA";
                    HttpContext.Current.Session["Asistente_Paso"] = "DNI";
                    return "Vamos a agendar la cita. Dime el documento del paciente. Si todavía no está registrado, podré registrarlo desde este chat.";
                }

                return PreguntaIAOnline(mensaje);
            }
            catch
            {
                return "No pude completar la operación. Verifica los datos e inténtalo nuevamente.";
            }
        }

        private static bool EsAdministradorActual()
        {
            Usuario actual = HttpContext.Current.Session["UserSessionEmpleado"] as Usuario;
            return actual != null && string.Equals((actual.TipUser ?? "").Trim(), "Administrador", StringComparison.OrdinalIgnoreCase);
        }

        private static string ProcesarCrearPaciente(string mensaje)
        {
            string paso = Convert.ToString(HttpContext.Current.Session["Asistente_Paso"]);
            if (paso == "DNI")
            {
                string dni = ExtraerDocumento(mensaje);
                if (string.IsNullOrEmpty(dni)) return "Dime el número de documento del paciente.";
                Paciente existente = PacienteLN.getInstance().BuscarPacienteDNI(dni);
                if (existente != null && existente.IdPaciente > 0)
                {
                    LimpiarAsistente();
                    return "Ya existe un paciente con ese documento: " + existente.Nombres + " " + existente.ApPaterno + ". No creé un duplicado.";
                }
                HttpContext.Current.Session["Asistente_PacienteDNI"] = dni;
                HttpContext.Current.Session["Asistente_Paso"] = "NOMBRES";
                return "¿Cuáles son los nombres del paciente?";
            }
            if (paso == "NOMBRES")
            {
                if (mensaje.Length < 2) return "Escribe los nombres del paciente.";
                HttpContext.Current.Session["Asistente_PacienteNombres"] = mensaje;
                HttpContext.Current.Session["Asistente_Paso"] = "APPATERNO";
                return "¿Cuál es el apellido paterno?";
            }
            if (paso == "APPATERNO")
            {
                if (mensaje.Length < 2) return "Escribe el apellido paterno.";
                HttpContext.Current.Session["Asistente_PacienteApPaterno"] = mensaje;
                HttpContext.Current.Session["Asistente_Paso"] = "APMATERNO";
                return "¿Cuál es el apellido materno? Si no tiene, escribe «No aplica».";
            }
            if (paso == "APMATERNO")
            {
                HttpContext.Current.Session["Asistente_PacienteApMaterno"] = Normalizar(mensaje) == "no aplica" ? "" : mensaje;
                HttpContext.Current.Session["Asistente_Paso"] = "EDAD";
                return "¿Qué edad tiene el paciente?";
            }
            if (paso == "EDAD")
            {
                int edad;
                if (!int.TryParse(mensaje, out edad) || edad < 0 || edad > 120) return "Dime una edad válida entre 0 y 120 años.";
                HttpContext.Current.Session["Asistente_PacienteEdad"] = edad.ToString();
                HttpContext.Current.Session["Asistente_Paso"] = "SEXO";
                return "¿Cuál es el sexo del paciente? Escribe «Femenino» o «Masculino».";
            }
            if (paso == "SEXO")
            {
                string sexo = Normalizar(mensaje);
                if (!sexo.Contains("femenino") && !sexo.Contains("masculino") && sexo != "f" && sexo != "m")
                    return "Escribe «Femenino» o «Masculino».";
                HttpContext.Current.Session["Asistente_PacienteSexo"] = (sexo == "f" || sexo.Contains("femenino")) ? "F" : "M";
                HttpContext.Current.Session["Asistente_Paso"] = "TELEFONO";
                return "¿Cuál es el teléfono de contacto?";
            }
            if (paso == "TELEFONO")
            {
                if (mensaje.Length < 5) return "Dime un teléfono de contacto válido.";
                HttpContext.Current.Session["Asistente_PacienteTelefono"] = mensaje;
                HttpContext.Current.Session["Asistente_Paso"] = "DIRECCION";
                return "¿Cuál es la dirección del paciente? Si no desea indicarla, escribe «No aplica».";
            }
            if (paso == "DIRECCION")
            {
                HttpContext.Current.Session["Asistente_PacienteDireccion"] = Normalizar(mensaje) == "no aplica" ? "" : mensaje;
                HttpContext.Current.Session["Asistente_Paso"] = "CONFIRMAR_PACIENTE";
                return "Confirma el registro escribiendo «confirmar». Documento: " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_PacienteDNI"]) + "; nombres: " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_PacienteNombres"]) + "; apellidos: " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_PacienteApPaterno"]) + " " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_PacienteApMaterno"]) + "; edad: " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_PacienteEdad"]) + "; sexo: " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_PacienteSexo"]) + "; teléfono: " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_PacienteTelefono"]) + "; dirección: " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_PacienteDireccion"]) + ".";
            }
            if (paso == "CONFIRMAR_PACIENTE")
            {
                if (!Contiene(Normalizar(mensaje), "confirmar", "si", "sí", "guardar"))
                    return "No guardé nada todavía. Escribe «confirmar» para guardar o «cancelar» para salir.";
                Paciente paciente = new Paciente();
                paciente.IdPaciente = 0;
                paciente.NroDocumento = Convert.ToString(HttpContext.Current.Session["Asistente_PacienteDNI"]);
                paciente.Nombres = Convert.ToString(HttpContext.Current.Session["Asistente_PacienteNombres"]);
                paciente.ApPaterno = Convert.ToString(HttpContext.Current.Session["Asistente_PacienteApPaterno"]);
                paciente.ApMaterno = Convert.ToString(HttpContext.Current.Session["Asistente_PacienteApMaterno"]);
                paciente.Edad = Convert.ToInt32(HttpContext.Current.Session["Asistente_PacienteEdad"]);
                paciente.Sexo = Convert.ToString(HttpContext.Current.Session["Asistente_PacienteSexo"]) == "F" ? 'F' : 'M';
                paciente.Telefono = Convert.ToString(HttpContext.Current.Session["Asistente_PacienteTelefono"]);
                paciente.Direccion = Convert.ToString(HttpContext.Current.Session["Asistente_PacienteDireccion"]);
                paciente.Estado = true;
                bool ok = PacienteLN.getInstance().RegistrarPaciente(paciente);
                string nombre = (paciente.Nombres + " " + paciente.ApPaterno + " " + paciente.ApMaterno).Trim();
                bool continuarCita = Convert.ToString(HttpContext.Current.Session["Asistente_ContinuarCita"]) == "1";
                if (ok && continuarCita)
                {
                    Paciente guardado = PacienteLN.getInstance().BuscarPacienteDNI(paciente.NroDocumento);
                    LimpiarAsistente();
                    if (guardado == null || guardado.IdPaciente <= 0)
                        return "El paciente se registró, pero no pude recuperarlo por documento. Intenta iniciar la cita nuevamente.";
                    HttpContext.Current.Session["Asistente_Flujo"] = "CITA";
                    HttpContext.Current.Session["Asistente_Paso"] = "PROBLEMA";
                    HttpContext.Current.Session["Asistente_PacienteId"] = guardado.IdPaciente.ToString();
                    HttpContext.Current.Session["Asistente_PacienteNombre"] = nombre;
                    return "Paciente registrado correctamente: " + nombre + ". Ahora dime cuál es el problema o motivo de consulta para asignar automáticamente la especialidad.";
                }
                LimpiarAsistente();
                return ok ? "Paciente registrado correctamente en el sistema: " + nombre + ". Ya puedes usar su documento para agendar una cita."
                          : "No se pudo guardar el paciente. Revisa si el documento ya existe o si la base de datos rechazó el registro.";
            }
            LimpiarAsistente();
            return "El registro se reinició. Escribe «registrar paciente» para comenzar de nuevo.";
        }

        private static string ProcesarCrearMedico(string mensaje)
        {
            string paso = Convert.ToString(HttpContext.Current.Session["Asistente_Paso"]);
            if (paso == "DNI")
            {
                string dni = ExtraerDocumento(mensaje);
                if (string.IsNullOrEmpty(dni)) return "Dime el documento del médico.";
                if (MedicoLN.getInstance().ListarMedicos().Any(x => x.NroDocumento == dni))
                    return "Ya existe un médico con ese documento. No creé un duplicado.";
                HttpContext.Current.Session["Asistente_MedicoDNI"] = dni;
                HttpContext.Current.Session["Asistente_Paso"] = "NOMBRES";
                return "¿Cuáles son los nombres del médico?";
            }
            if (paso == "NOMBRES") { if (mensaje.Length < 2) return "Escribe los nombres."; HttpContext.Current.Session["Asistente_MedicoNombres"] = mensaje; HttpContext.Current.Session["Asistente_Paso"] = "APPATERNO"; return "¿Cuál es el apellido paterno?"; }
            if (paso == "APPATERNO") { if (mensaje.Length < 2) return "Escribe el apellido paterno."; HttpContext.Current.Session["Asistente_MedicoApPaterno"] = mensaje; HttpContext.Current.Session["Asistente_Paso"] = "APMATERNO"; return "¿Cuál es el apellido materno? Si no tiene, escribe «No aplica»."; }
            if (paso == "APMATERNO")
            {
                HttpContext.Current.Session["Asistente_MedicoApMaterno"] = Normalizar(mensaje) == "no aplica" ? "" : mensaje;
                List<Especialidad> lista = EspecialidadLN.getInstance().Listar();
                if (lista == null || lista.Count == 0) { LimpiarAsistente(); return "No hay especialidades configuradas en la base de datos."; }
                HttpContext.Current.Session["Asistente_Paso"] = "ESPECIALIDAD_MEDICO";
                return "¿Qué especialidad tendrá? Opciones disponibles: " + string.Join(", ", lista.Select(x => x.Descripcion)) + ".";
            }
            if (paso == "ESPECIALIDAD_MEDICO")
            {
                List<Especialidad> lista = EspecialidadLN.getInstance().Listar();
                Especialidad esp = lista.FirstOrDefault(x => Normalizar(x.Descripcion) == Normalizar(mensaje)) ??
                    lista.FirstOrDefault(x => Normalizar(x.Descripcion).Contains(Normalizar(mensaje)));
                if (esp == null) return "No encontré esa especialidad. Opciones: " + string.Join(", ", lista.Select(x => x.Descripcion)) + ".";
                HttpContext.Current.Session["Asistente_MedicoEspecialidadId"] = esp.IdEspecialidad.ToString();
                HttpContext.Current.Session["Asistente_MedicoEspecialidadNombre"] = esp.Descripcion;
                HttpContext.Current.Session["Asistente_Paso"] = "CONFIRMAR_MEDICO";
                return "Confirma escribiendo «confirmar» para registrar a " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_MedicoNombres"]) + " " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_MedicoApPaterno"]) +
                    " con documento " + Convert.ToString(HttpContext.Current.Session["Asistente_MedicoDNI"]) +
                    " y especialidad " + esp.Descripcion + ".";
            }
            if (paso == "CONFIRMAR_MEDICO")
            {
                if (!Contiene(Normalizar(mensaje), "confirmar", "si", "sí", "guardar")) return "Escribe «confirmar» para guardar o «cancelar» para salir.";
                Medico m = new Medico();
                m.IdMedico = 0; m.RTipoEmpleado = new TipoEmpleado(); m.RTipoEmpleado.ID = 1002;
                m.NroDocumento = Convert.ToString(HttpContext.Current.Session["Asistente_MedicoDNI"]);
                m.Nombre = Convert.ToString(HttpContext.Current.Session["Asistente_MedicoNombres"]);
                m.ApPaterno = Convert.ToString(HttpContext.Current.Session["Asistente_MedicoApPaterno"]);
                m.ApMaterno = Convert.ToString(HttpContext.Current.Session["Asistente_MedicoApMaterno"]);
                m.Especialidad = new Especialidad(); m.Especialidad.IdEspecialidad = Convert.ToInt32(HttpContext.Current.Session["Asistente_MedicoEspecialidadId"]); m.Estado = true;
                bool ok = MedicoLN.getInstance().RegistrarMedico(m);
                string nombre = (m.Nombre + " " + m.ApPaterno).Trim();
                string especialidadNombre = Convert.ToString(HttpContext.Current.Session["Asistente_MedicoEspecialidadNombre"]);
                LimpiarAsistente();
                return ok ? "Médico registrado correctamente: " + nombre + ", especialidad " + especialidadNombre + "."
                          : "No se pudo registrar el médico. Verifica los datos y la base de datos.";
            }
            LimpiarAsistente(); return "El registro se reinició. Escribe «registrar médico» para comenzar.";
        }

        private static string ProcesarCrearEnfermera(string mensaje)
        {
            string paso = Convert.ToString(HttpContext.Current.Session["Asistente_Paso"]);
            if (paso == "DNI")
            {
                string dni = ExtraerDocumento(mensaje);
                if (string.IsNullOrEmpty(dni)) return "Dime el documento de la enfermera.";
                if (EnfermeraLN.getInstance().ListarEnfermeras().Any(x => x.NroDocumento == dni))
                    return "Ya existe una enfermera con ese documento. No creé un duplicado.";
                HttpContext.Current.Session["Asistente_EnfermeraDNI"] = dni;
                HttpContext.Current.Session["Asistente_Paso"] = "NOMBRES";
                return "¿Cuáles son los nombres de la enfermera?";
            }
            if (paso == "NOMBRES") { if (mensaje.Length < 2) return "Escribe los nombres."; HttpContext.Current.Session["Asistente_EnfermeraNombres"] = mensaje; HttpContext.Current.Session["Asistente_Paso"] = "APPATERNO"; return "¿Cuál es el apellido paterno?"; }
            if (paso == "APPATERNO") { if (mensaje.Length < 2) return "Escribe el apellido paterno."; HttpContext.Current.Session["Asistente_EnfermeraApPaterno"] = mensaje; HttpContext.Current.Session["Asistente_Paso"] = "APMATERNO"; return "¿Cuál es el apellido materno? Si no tiene, escribe «No aplica»."; }
            if (paso == "APMATERNO") { HttpContext.Current.Session["Asistente_EnfermeraApMaterno"] = Normalizar(mensaje) == "no aplica" ? "" : mensaje; HttpContext.Current.Session["Asistente_Paso"] = "TIPO_ENFERMERA"; return "¿Qué tipo de enfermera es? Escribe «Técnica» o «Licenciada»."; }
            if (paso == "TIPO_ENFERMERA")
            {
                string tipo = Normalizar(mensaje);
                if (!tipo.Contains("tecnica") && !tipo.Contains("licenciada")) return "Elige «Técnica» o «Licenciada».";
                HttpContext.Current.Session["Asistente_EnfermeraTipo"] = tipo.Contains("licenciada") ? "Licenciada" : "Técnica";
                HttpContext.Current.Session["Asistente_Paso"] = "CONFIRMAR_ENFERMERA";
                return "Confirma escribiendo «confirmar» para registrar a " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_EnfermeraNombres"]) + " " +
                    Convert.ToString(HttpContext.Current.Session["Asistente_EnfermeraApPaterno"]) +
                    " con documento " + Convert.ToString(HttpContext.Current.Session["Asistente_EnfermeraDNI"]) +
                    " como " + Convert.ToString(HttpContext.Current.Session["Asistente_EnfermeraTipo"]) + ".";
            }
            if (paso == "CONFIRMAR_ENFERMERA")
            {
                if (!Contiene(Normalizar(mensaje), "confirmar", "si", "sí", "guardar")) return "Escribe «confirmar» para guardar o «cancelar» para salir.";
                Enfermera e = new Enfermera(); e.IdEnfermera = 0; e.RTipoEmpleado = new TipoEmpleado(); e.RTipoEmpleado.ID = 1003;
                e.NroDocumento = Convert.ToString(HttpContext.Current.Session["Asistente_EnfermeraDNI"]);
                e.Nombre = Convert.ToString(HttpContext.Current.Session["Asistente_EnfermeraNombres"]);
                e.ApPaterno = Convert.ToString(HttpContext.Current.Session["Asistente_EnfermeraApPaterno"]);
                e.ApMaterno = Convert.ToString(HttpContext.Current.Session["Asistente_EnfermeraApMaterno"]);
                e.TipoEnfermera = Convert.ToString(HttpContext.Current.Session["Asistente_EnfermeraTipo"]); e.Estado = true;
                bool ok = EnfermeraLN.getInstance().RegistrarEnfermera(e);
                string nombre = (e.Nombre + " " + e.ApPaterno).Trim();
                LimpiarAsistente();
                return ok ? "Enfermera registrada correctamente: " + nombre + "." : "No se pudo registrar la enfermera. Verifica los datos y la base de datos.";
            }
            LimpiarAsistente(); return "El registro se reinició. Escribe «registrar enfermera» para comenzar.";
        }

        private static string ProcesarCrearUsuario(string mensaje)
        {
            string paso = Convert.ToString(HttpContext.Current.Session["Asistente_Paso"]);

            if (paso == "DNI")
            {
                string dni = ExtraerDocumento(mensaje);
                if (string.IsNullOrEmpty(dni))
                    return "Necesito el número de documento del empleado. Por ejemplo: 12345678.";

                Empleado empleado = EmpleadoLN.getInstance().BuscarEmpleado(dni);
                if (empleado == null || empleado.ID <= 0)
                    return "No encontré un empleado con ese documento. Verifica el número e inténtalo otra vez.";

                HttpContext.Current.Session["Asistente_EmpleadoId"] = empleado.ID.ToString();
                HttpContext.Current.Session["Asistente_EmpleadoNombre"] =
                    (empleado.Nombre + " " + empleado.ApPaterno + " " + empleado.ApMaterno).Trim();

                HttpContext.Current.Session["Asistente_Paso"] = "USUARIO";
                return "Encontré a " + (empleado.Nombre + " " + empleado.ApPaterno).Trim() +
                       ". Ahora dime el nombre de usuario que quieres crear.";
            }

            if (paso == "USUARIO")
            {
                if (mensaje.Length < 3)
                    return "El nombre de usuario es demasiado corto. Dime otro.";

                HttpContext.Current.Session["Asistente_NombreUsuario"] = mensaje.Trim();
                HttpContext.Current.Session["Asistente_Paso"] = "CLAVE";
                return "Perfecto. Ahora dime la contraseña que tendrá la cuenta.";
            }

            if (paso == "CLAVE")
            {
                if (mensaje.Length < 4)
                    return "La contraseña debe tener al menos 4 caracteres. Inténtalo nuevamente.";

                HttpContext.Current.Session["Asistente_Clave"] = mensaje;
                HttpContext.Current.Session["Asistente_Paso"] = "ROL";
                return "¿Qué rol tendrá? Escribe «Administrador» o «Invitado».";
            }

            if (paso == "ROL")
            {
                string rol = Normalizar(mensaje);
                string tipo = rol.Contains("administrador") ? "Administrador" :
                              (rol.Contains("invitado") ? "Invitado" : "");

                if (string.IsNullOrEmpty(tipo))
                    return "El rol debe ser «Administrador» o «Invitado».";

                int idEmpleado = Convert.ToInt32(HttpContext.Current.Session["Asistente_EmpleadoId"]);
                string nombreUsuario = Convert.ToString(HttpContext.Current.Session["Asistente_NombreUsuario"]);
                string clave = Convert.ToString(HttpContext.Current.Session["Asistente_Clave"]);

                List<Usuario> usuariosExistentes = UsuarioLN.getInstance().ListarUsuarios();
                if (usuariosExistentes.Any(x => !string.IsNullOrWhiteSpace(x.user) &&
                    x.user.Equals(Convert.ToString(HttpContext.Current.Session["Asistente_NombreUsuario"]), StringComparison.OrdinalIgnoreCase)))
                {
                    HttpContext.Current.Session["Asistente_Paso"] = "USUARIO";
                    return "Ese nombre de usuario ya existe. Dime otro nombre de usuario.";
                }

                Usuario nuevo = new Usuario();
                nuevo.IdUsuario = 0;
                nuevo.user = nombreUsuario;
                nuevo.password = clave;
                nuevo.ID = idEmpleado;
                nuevo.TipUser = tipo;
                nuevo.estado = true;

                bool ok = UsuarioLN.getInstance().RegistrarUsuario(nuevo);
                string empleadoNombre = Convert.ToString(HttpContext.Current.Session["Asistente_EmpleadoNombre"]);
                LimpiarAsistente();

                return ok
                    ? "Usuario creado correctamente para " + empleadoNombre + ". Usuario: " + nombreUsuario + "."
                    : "No se pudo crear el usuario. Puede que el usuario ya exista o que la base de datos haya rechazado el registro.";
            }

            LimpiarAsistente();
            return "La operación de usuario se reinició. Si quieres, dime «crear usuario» para comenzar.";
        }

        private static string ProcesarCrearCita(string mensaje)
        {
            string paso = Convert.ToString(HttpContext.Current.Session["Asistente_Paso"]);

            if (paso == "DNI")
            {
                string dni = ExtraerDocumento(mensaje);
                if (string.IsNullOrEmpty(dni))
                    return "Necesito el documento del paciente. Por ejemplo: 12345678.";

                Paciente paciente = PacienteLN.getInstance().BuscarPacienteDNI(dni);
                if (paciente == null || paciente.IdPaciente <= 0)
                {
                    HttpContext.Current.Session["Asistente_Flujo"] = "PACIENTE";
                    HttpContext.Current.Session["Asistente_Paso"] = "NOMBRES";
                    HttpContext.Current.Session["Asistente_PacienteDNI"] = dni;
                    HttpContext.Current.Session["Asistente_ContinuarCita"] = "1";
                    return "No encontré ese documento. Vamos a registrar al paciente desde este chat. ¿Cuáles son sus nombres?";
                }

                HttpContext.Current.Session["Asistente_PacienteId"] = paciente.IdPaciente.ToString();
                HttpContext.Current.Session["Asistente_PacienteNombre"] =
                    (paciente.Nombres + " " + paciente.ApPaterno).Trim();

                HttpContext.Current.Session["Asistente_Paso"] = "PROBLEMA";
                return "Paciente encontrado: " + (paciente.Nombres + " " + paciente.ApPaterno).Trim() +
                       ". Cuéntame brevemente el problema o motivo de consulta para asignar automáticamente la especialidad.";
            }

            if (paso == "PROBLEMA")
            {
                if (mensaje.Trim().Length < 3) return "Cuéntame un poco más sobre el problema o motivo de consulta.";
                HttpContext.Current.Session["Asistente_Problema"] = mensaje.Trim();
                List<Especialidad> especialidades = EspecialidadLN.getInstance().Listar();
                string problema = Normalizar(mensaje);
                string[] palabrasOtorrino = { "oido", "oído", "nariz", "garganta", "audicion", "sinus", "otorrino", "amigdal" };
                string[] palabrasPediatria = { "nino", "niño", "nina", "niña", "bebe", "bebe", "pediatr" };
                string[] palabrasDermato = { "piel", "acne", "dermat", "sarpullido" };
                string[] palabrasOftalmo = { "ojo", "vista", "vision", "visión" };
                string[] palabrasGineco = { "embarazo", "menstru", "gineco" };
                string[] palabrasTrauma = { "hueso", "fractura", "golpe", "articulacion", "dolor de rodilla" };
                string preferida = "";
                if (palabrasOtorrino.Any(x => problema.Contains(Normalizar(x)))) preferida = "otorrino";
                else if (palabrasPediatria.Any(x => problema.Contains(Normalizar(x)))) preferida = "pediatr";
                else if (palabrasDermato.Any(x => problema.Contains(Normalizar(x)))) preferida = "dermat";
                else if (palabrasOftalmo.Any(x => problema.Contains(Normalizar(x)))) preferida = "oftalm";
                else if (palabrasGineco.Any(x => problema.Contains(Normalizar(x)))) preferida = "gineco";
                else if (palabrasTrauma.Any(x => problema.Contains(Normalizar(x)))) preferida = "traumat";
                else preferida = "general";

                Especialidad seleccionada = especialidades.FirstOrDefault(x => Normalizar(x.Descripcion).Contains(preferida));
                if (seleccionada == null && preferida != "general")
                    seleccionada = especialidades.FirstOrDefault(x => Normalizar(x.Descripcion).Contains("general"));
                if (seleccionada == null)
                    seleccionada = especialidades.FirstOrDefault();
                if (seleccionada == null)
                {
                    LimpiarAsistente();
                    return "No hay especialidades configuradas en la base de datos. No puedo asignar un médico todavía.";
                }

                HttpContext.Current.Session["Asistente_EspecialidadId"] = seleccionada.IdEspecialidad.ToString();
                HttpContext.Current.Session["Asistente_EspecialidadNombre"] = seleccionada.Descripcion;
                HttpContext.Current.Session["Asistente_Paso"] = "FECHA";
                return "Por el motivo indicado, asignaré la especialidad " + seleccionada.Descripcion +
                    ". ¿Para qué fecha quieres la cita? Puedes escribir «mañana», «hoy» o una fecha como 25/10/2026.";
            }

            if (paso == "FECHA")
            {
                DateTime fecha;
                if (!TryParseFecha(mensaje, out fecha))
                    return "No entendí la fecha. Escríbela como 25/08/2026, o dime «hoy» o «mañana».";

                if (fecha.Date < DateTime.Now.Date)
                    return "La fecha debe ser hoy o una fecha futura.";

                int idEspecialidad = Convert.ToInt32(HttpContext.Current.Session["Asistente_EspecialidadId"]);
                List<HorarioAtencion> horarios = HorarioAtencionLN.getInstance().ListarHorarioReservas(idEspecialidad, fecha.Date);

                // Si no existe ningún turno libre para la fecha solicitada, crear un horario
                // persistente y asignar la cita directamente. No crear pacientes duplicados.
                if (horarios == null || horarios.Count == 0)
                {
                    HorarioAtencion horarioAutomatico = CrearHorarioAutomaticoParaCita(idEspecialidad, fecha.Date);
                    if (horarioAutomatico == null || horarioAutomatico.Medico == null ||
                        horarioAutomatico.Medico.IdMedico <= 0 || horarioAutomatico.Hora == null)
                        return "No pude crear un horario automático. Verifica la conexión y los procedimientos almacenados.";

                    int idPacienteAuto = Convert.ToInt32(HttpContext.Current.Session["Asistente_PacienteId"]);
                    Cita citaAutomatica = new Cita();
                    citaAutomatica.Paciente.IdPaciente = idPacienteAuto;
                    citaAutomatica.Medico.IdMedico = horarioAutomatico.Medico.IdMedico;
                    citaAutomatica.FechaReserva = horarioAutomatico.Fecha;
                    citaAutomatica.Hora = horarioAutomatico.Hora.hora;
                    citaAutomatica.Observacion = Convert.ToString(HttpContext.Current.Session["Asistente_Problema"]);

                    bool citaRegistrada = CitaLN.getInstance().RegistrarCita(citaAutomatica);
                    if (!citaRegistrada)
                        return "Creé el horario para el " + horarioAutomatico.Fecha.ToString("dd/MM/yyyy") +
                               " a las " + horarioAutomatico.Hora.hora +
                               ", pero no pude confirmar la cita. Intenta de nuevo.";

                    string pacienteNombreAuto = Convert.ToString(HttpContext.Current.Session["Asistente_PacienteNombre"]);
                    string especialidadAuto = Convert.ToString(HttpContext.Current.Session["Asistente_EspecialidadNombre"]);
                    string fechaAutoTexto = horarioAutomatico.Fecha.ToString("dd/MM/yyyy");
                    string horaAutoTexto = horarioAutomatico.Hora.hora;
                    LimpiarAsistente();
                    return "No había turnos libres, así que generé un horario y registré tu cita automáticamente. Paciente: " +
                           pacienteNombreAuto + ". Especialidad: " + especialidadAuto +
                           ". Fecha: " + fechaAutoTexto + ". Hora: " + horaAutoTexto + ".";
                }

                HttpContext.Current.Session["Asistente_Fecha"] = fecha.ToString("yyyy-MM-dd");
                HttpContext.Current.Session["Asistente_Horarios"] = SerializarHorarios(horarios);
                HttpContext.Current.Session["Asistente_Paso"] = "HORA";

                string opciones = string.Join(" | ", horarios.Select((h, i) =>
                    (i + 1) + ". " + h.Hora.hora + " - Dr(a). " + h.Medico.Nombre));

                return "Hay estos horarios disponibles para " + fecha.ToString("dd/MM/yyyy") +
                       ": " + opciones + ". Dime la hora que prefieres.";
            }

            if (paso == "HORA")
            {
                List<HorarioOpcion> horarios = DeserializarHorarios(
                    Convert.ToString(HttpContext.Current.Session["Asistente_Horarios"]));

                string hora = ExtraerHora(mensaje);
                HorarioOpcion seleccion = null;

                if (!string.IsNullOrEmpty(hora))
                    seleccion = horarios.FirstOrDefault(x => NormalizarHora(x.Hora) == NormalizarHora(hora));

                if (seleccion == null)
                {
                    int numero;
                    if (int.TryParse(mensaje.Trim(), out numero) && numero >= 1 && numero <= horarios.Count)
                        seleccion = horarios[numero - 1];
                }

                if (seleccion == null)
                {
                    string opciones = string.Join(" | ", horarios.Select((h, i) => (i + 1) + ". " + h.Hora));
                    return "No encontré ese horario. Elige uno de estos: " + opciones;
                }

                DateTime fecha = DateTime.Parse(Convert.ToString(HttpContext.Current.Session["Asistente_Fecha"]));
                int idPaciente = Convert.ToInt32(HttpContext.Current.Session["Asistente_PacienteId"]);

                Cita cita = new Cita();
                cita.Paciente.IdPaciente = idPaciente;
                cita.Medico.IdMedico = seleccion.IdMedico;
                cita.FechaReserva = fecha;
                cita.Hora = seleccion.Hora;
                cita.Observacion = Convert.ToString(HttpContext.Current.Session["Asistente_Problema"]);

                bool ok = CitaLN.getInstance().RegistrarCita(cita);
                string pacienteNombre = Convert.ToString(HttpContext.Current.Session["Asistente_PacienteNombre"]);
                string especialidad = Convert.ToString(HttpContext.Current.Session["Asistente_EspecialidadNombre"]);

                LimpiarAsistente();

                return ok
                    ? "¡Cita registrada correctamente! Paciente: " + pacienteNombre +
                      ". Especialidad: " + especialidad +
                      ". Fecha: " + fecha.ToString("dd/MM/yyyy") +
                      ". Hora: " + seleccion.Hora + "."
                    : "No se pudo registrar la cita. El horario puede haber sido ocupado. Intenta reservar nuevamente.";
            }

            LimpiarAsistente();
            return "La operación de cita se reinició. Si quieres, dime «crear cita» para comenzar.";
        }

        private static HorarioAtencion CrearHorarioAutomaticoParaCita(int idEspecialidad, DateTime fechaSolicitada)
        {
            List<Medico> medicos = MedicoLN.getInstance().ListarMedicos() ?? new List<Medico>();
            string documentoFicticio = "99" + idEspecialidad.ToString("D6");

            // Reutilizar un médico ya registrado de la especialidad.
            Medico medico = medicos.FirstOrDefault(m =>
                m.Especialidad != null &&
                string.Equals(Normalizar(m.Especialidad.Descripcion),
                    Normalizar(Convert.ToString(HttpContext.Current.Session["Asistente_EspecialidadNombre"])),
                    StringComparison.Ordinal));

            // Solo crear el perfil NN si realmente no existe ningún médico para esa especialidad.
            if (medico == null)
            {
                medico = medicos.FirstOrDefault(m =>
                    string.Equals((m.NroDocumento ?? "").Trim(), documentoFicticio, StringComparison.OrdinalIgnoreCase));
            }

            if (medico == null)
            {
                Medico nuevo = new Medico();
                nuevo.RTipoEmpleado.ID = 1002;
                nuevo.Nombre = "NN";
                nuevo.ApPaterno = "NN";
                nuevo.ApMaterno = "NN";
                nuevo.NroDocumento = documentoFicticio;
                nuevo.Especialidad = new Especialidad { IdEspecialidad = idEspecialidad };
                nuevo.Estado = true;

                bool registrado = MedicoLN.getInstance().RegistrarMedico(nuevo);
                medicos = MedicoLN.getInstance().ListarMedicos() ?? new List<Medico>();
                medico = medicos.FirstOrDefault(m =>
                    string.Equals((m.NroDocumento ?? "").Trim(), documentoFicticio, StringComparison.OrdinalIgnoreCase));
                if (!registrado && medico == null)
                    throw new InvalidOperationException("No se pudo registrar el médico automático.");
            }

            if (medico == null || medico.IdMedico <= 0)
                throw new InvalidOperationException("No hay un médico válido para asignar el horario.");

            List<HorarioAtencion> horariosEspecialidad =
                HorarioAtencionLN.getInstance().ListarHorario(idEspecialidad) ?? new List<HorarioAtencion>();
            List<Cita> citas = CitaLN.getInstance().ListarCitas() ?? new List<Cita>();

            DateTime fecha = fechaSolicitada.Date;
            // Buscar un hueco entre las 09:00 y las 21:00. Si el día está lleno,
            // avanzar al siguiente día. Una cita a las 20:00 permite asignar las 21:00.
            for (int dias = 0; dias < 60; dias++, fecha = fecha.AddDays(1))
            {
                for (int hora = 9; hora <= 21; hora++)
                {
                    DateTime instante = fecha.AddHours(hora);
                    if (instante <= DateTime.Now) continue;

                    string horaTexto = instante.ToString("HH:mm");
                    bool horarioOcupado = horariosEspecialidad.Any(h =>
                        h.Fecha.Date == fecha.Date && h.Medico != null &&
                        h.Medico.IdMedico == medico.IdMedico && h.Hora != null &&
                        NormalizarHoraLocal(h.Hora.hora) == horaTexto);

                    bool citaOcupada = citas.Any(c =>
                        c.FechaReserva.Date == fecha.Date && c.Medico != null &&
                        c.Medico.IdMedico == medico.IdMedico &&
                        NormalizarHoraLocal(c.Hora) == horaTexto);

                    if (horarioOcupado || citaOcupada) continue;

                    HorarioAtencion creado = HorarioAtencionLN.getInstance().RegistrarHorarioAtencion(
                        new HorarioAtencion
                        {
                            Medico = new Medico { IdMedico = medico.IdMedico },
                            Hora = new Hora { hora = horaTexto },
                            Fecha = fecha,
                            Estado = true
                        });

                    if (creado == null) continue;
                    creado.Medico = new Medico { IdMedico = medico.IdMedico };
                    if (creado.Hora == null) creado.Hora = new Hora { hora = horaTexto };
                    if (creado.Fecha == DateTime.MinValue) creado.Fecha = fecha;
                    return creado;
                }
            }

            return null;
        }

        private static string NormalizarHoraLocal(string hora)
        {
            TimeSpan valor;
            if (TimeSpan.TryParse((hora ?? "").Trim(), out valor))
                return valor.ToString(@"hh\:mm");
            return (hora ?? "").Trim();
        }

        private static string PreguntaIAOnline(string mensaje)
        {
            try
            {
                string prompt = ConstruirPromptConversacion(mensaje);

                // Servicio online sin API key. Se usan endpoints documentados públicamente.
                // El primero es el recomendado; los siguientes funcionan como respaldo.
                // Servicios públicos sin API key. Se prueban varios endpoints
                // y se descartan respuestas de error o respuestas que solo contienen
                // el nombre del proveedor.
                // Servicios públicos de IA sin API key. Se usan los parámetros
                // que figuran en la documentación actual de los endpoints.
                string encodedPrompt = Uri.EscapeDataString(prompt);
                string[] urls =
                {
                    "https://prexzyapis.com/ai/chatgpt?prompt=" + encodedPrompt,
                    "https://prexzyapis.com/ai/gpt-5?text=" + encodedPrompt,
                    "https://prexzyapis.com/ai/gemini25?prompt=" + encodedPrompt,
                    "https://prexzyapis.com/ai/gemma27free?prompt=" + encodedPrompt,
                    "https://prexzyapis.com/ai/ai4chat?prompt=" + encodedPrompt,
                    "https://prexzyapis.com/ai/ch?q=" + encodedPrompt
                };

                ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

                foreach (string url in urls)
                {
                    try
                    {
                        using (WebClient cliente = new WebClient())
                        {
                            cliente.Encoding = Encoding.UTF8;
                            cliente.Headers[HttpRequestHeader.UserAgent] = "ClinicaAsistente/1.0";
                            cliente.Headers[HttpRequestHeader.Accept] = "application/json,text/plain,*/*";

                            string respuesta = cliente.DownloadString(url);
                            string texto = ExtraerRespuestaIA(respuesta);

                            if (EsRespuestaIAValida(texto))
                            {
                                texto = LimpiarTextoIA(texto);
                                if (EsRespuestaIAValida(texto))
                                {
                                    GuardarConversacion(mensaje, texto);
                                    return texto;
                                }
                            }
                        }
                    }
                    catch
                    {
                        // Intenta el siguiente servicio de respaldo.
                    }
                }
            }
            catch
            {
                // Las operaciones internas de usuarios y citas no dependen de la IA online.
            }

            return "En este momento no pude conectarme con el servicio de IA en línea. " +
                   "Puedes volver a intentarlo en unos segundos o usar «crear usuario» y «crear cita» para las funciones del sistema.";
        }

        private static bool EsRespuestaIAValida(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return false;

            string t = texto.Trim();

            // No mostrar al usuario respuestas técnicas o el nombre del proveedor.
            if (t.StartsWith("{") || t.StartsWith("["))
                return false;

            string n = t.ToLowerInvariant().Trim();

            if (n == "prexzy" || n == "prezxy" ||
                n == "prexzyapis" || n == "prexzy apis" ||
                n == "prexzy api" || n == "prexzyapis.com")
                return false;

            if (n.Contains("error 404") || n.Contains("not found") ||
                n.Contains("endpoint not found") || n.Contains("service unavailable"))
                return false;

            return t.Length >= 2;
        }

        private static string LimpiarTextoIA(string texto)
        {
            if (string.IsNullOrWhiteSpace(texto))
                return "";

            string t = texto.Trim().Trim('"');

            // Algunos endpoints pueden devolver el nombre del proveedor
            // antes de la respuesta; no lo mostramos como mensaje del asistente.
            if (t.StartsWith("prexzy:", StringComparison.OrdinalIgnoreCase))
                t = t.Substring("prexzy:".Length).Trim();

            if (t.StartsWith("prezxy:", StringComparison.OrdinalIgnoreCase))
                t = t.Substring("prezxy:".Length).Trim();

            return t;
        }

        private static string ConstruirPromptConversacion(string mensaje)
        {
            StringBuilder sb = new StringBuilder();

            sb.AppendLine("Eres el Asistente IA de una aplicación web para gestionar una clínica.");
            sb.AppendLine("Responde siempre en español correcto, natural, amable y fácil de entender.");
            sb.AppendLine("Puedes conversar sobre temas generales, programación, tecnología, educación y cualquier pregunta permitida.");
            sb.AppendLine("Responde directamente a la pregunta del usuario y no repitas instrucciones del sistema.");
            sb.AppendLine("No inventes datos de pacientes, médicos, usuarios, citas, horarios ni resultados de la base de datos.");
            sb.AppendLine("Si el usuario quiere crear, consultar o gestionar información de la clínica, usa las funciones internas disponibles y confirma únicamente lo que el sistema haya realizado.");
            sb.AppendLine("Para información médica, ofrece orientación general y recomienda consultar a un profesional cuando corresponda.");
            sb.AppendLine("No afirmes que has creado, eliminado o reservado algo si el sistema no te lo confirmó.");
            sb.AppendLine("Mantén las respuestas claras y no demasiado largas.");
            sb.AppendLine();

            List<string> historial = HttpContext.Current.Session["Asistente_Historial"] as List<string>;
            if (historial != null && historial.Count > 0)
            {
                sb.AppendLine("Conversación reciente:");
                foreach (string linea in historial.Skip(Math.Max(0, historial.Count - 8)))
                    sb.AppendLine(linea);
                sb.AppendLine();
            }

            sb.AppendLine("Nueva pregunta del usuario:");
            sb.AppendLine(mensaje);

            return sb.ToString();
        }

        private static void GuardarConversacion(string pregunta, string respuesta)
        {
            List<string> historial = HttpContext.Current.Session["Asistente_Historial"] as List<string>;

            if (historial == null)
            {
                historial = new List<string>();
                HttpContext.Current.Session["Asistente_Historial"] = historial;
            }

            historial.Add("Usuario: " + pregunta);
            historial.Add("Asistente: " + respuesta);

            if (historial.Count > 12)
                historial.RemoveRange(0, historial.Count - 12);
        }

        private static string ExtraerRespuestaIA(string respuesta)
        {
            if (string.IsNullOrWhiteSpace(respuesta))
                return "";

            string limpio = respuesta.Trim();

            try
            {
                JavaScriptSerializer json = new JavaScriptSerializer();
                object datos = json.DeserializeObject(limpio);
                string extraido = BuscarTextoRespuesta(datos);

                if (!string.IsNullOrWhiteSpace(extraido))
                    return extraido.Trim();
            }
            catch
            {
                // Si no es JSON, se devuelve el texto directamente.
            }

            return limpio.Trim('"');
        }

        private static string BuscarTextoRespuesta(object datos)
        {
            if (datos == null)
                return "";

            string texto = datos as string;
            if (!string.IsNullOrWhiteSpace(texto))
                return texto;

            Dictionary<string, object> dic = datos as Dictionary<string, object>;
            if (dic != null)
            {
                string[] claves = { "result", "response", "answer", "text", "message", "content" };

                foreach (string clave in claves)
                {
                    object valor;
                    if (dic.TryGetValue(clave, out valor))
                    {
                        string encontrado = BuscarTextoRespuesta(valor);
                        if (!string.IsNullOrWhiteSpace(encontrado))
                            return encontrado;
                    }
                }

                foreach (object valor in dic.Values)
                {
                    string encontrado = BuscarTextoRespuesta(valor);
                    if (!string.IsNullOrWhiteSpace(encontrado))
                        return encontrado;
                }
            }

            object[] arreglo = datos as object[];
            if (arreglo != null)
            {
                foreach (object valor in arreglo)
                {
                    string encontrado = BuscarTextoRespuesta(valor);
                    if (!string.IsNullOrWhiteSpace(encontrado))
                        return encontrado;
                }
            }

            return "";
        }

        private static bool EsCancelar(string texto)
        {
            string n = Normalizar(texto);
            return n == "cancelar" || n == "cancelar operacion" || n == "salir" ||
                   n == "reiniciar" || n == "empezar de nuevo";
        }

        private static bool Contiene(string texto, params string[] opciones)
        {
            return opciones.Any(x => texto.Contains(Normalizar(x)));
        }

        private static string Normalizar(string texto)
        {
            if (string.IsNullOrEmpty(texto)) return "";
            string n = texto.ToLowerInvariant().Trim();
            n = n.Replace("á", "a").Replace("é", "e").Replace("í", "i")
                 .Replace("ó", "o").Replace("ú", "u").Replace("ü", "u").Replace("ñ", "n");
            return Regex.Replace(n, @"\s+", " ");
        }

        private static string ExtraerDocumento(string texto)
        {
            Match m = Regex.Match(texto ?? "", @"\b\d{6,12}\b");
            return m.Success ? m.Value : "";
        }

        private static bool TryParseFecha(string texto, out DateTime fecha)
        {
            string n = Normalizar(texto);
            if (n.Contains("manana"))
            {
                fecha = DateTime.Now.Date.AddDays(1);
                return true;
            }

            if (n == "hoy" || n.Contains("hoy"))
            {
                fecha = DateTime.Now.Date;
                return true;
            }

            string[] formatos = { "dd/MM/yyyy", "d/M/yyyy", "yyyy-MM-dd", "dd-MM-yyyy", "d-M-yyyy" };
            return DateTime.TryParseExact(texto.Trim(), formatos,
                System.Globalization.CultureInfo.InvariantCulture,
                System.Globalization.DateTimeStyles.None, out fecha)
                || DateTime.TryParse(texto.Trim(),
                    new System.Globalization.CultureInfo("es-CO"),
                    System.Globalization.DateTimeStyles.None, out fecha);
        }

        private static string ExtraerHora(string texto)
        {
            Match m = Regex.Match((texto ?? "").ToLowerInvariant(),
                @"\b([01]?\d|2[0-3])(?::([0-5]\d))?\s*(am|pm)?\b");

            if (!m.Success) return "";

            int h = Convert.ToInt32(m.Groups[1].Value);
            int min = m.Groups[2].Success ? Convert.ToInt32(m.Groups[2].Value) : 0;
            string ampm = m.Groups[3].Value;

            if (ampm == "pm" && h < 12) h += 12;
            if (ampm == "am" && h == 12) h = 0;

            return h.ToString("00") + ":" + min.ToString("00");
        }

        private static string NormalizarHora(string hora)
        {
            if (string.IsNullOrEmpty(hora)) return "";
            return hora.Trim().Replace(".", ":").ToLowerInvariant();
        }

        private static string SerializarHorarios(List<HorarioAtencion> horarios)
        {
            List<HorarioOpcion> lista = horarios.Select(x => new HorarioOpcion
            {
                IdHorario = x.IdHorarioAtencion,
                IdMedico = x.Medico.IdMedico,
                Hora = x.Hora.hora,
                Medico = x.Medico.Nombre
            }).ToList();

            return new JavaScriptSerializer().Serialize(lista);
        }

        private static List<HorarioOpcion> DeserializarHorarios(string texto)
        {
            if (string.IsNullOrEmpty(texto))
                return new List<HorarioOpcion>();

            return new JavaScriptSerializer().Deserialize<List<HorarioOpcion>>(texto)
                   ?? new List<HorarioOpcion>();
        }

        private static void LimpiarAsistente()
        {
            string[] claves =
            {
                "Asistente_Flujo", "Asistente_Paso", "Asistente_EmpleadoId",
                "Asistente_EmpleadoNombre", "Asistente_NombreUsuario",
                "Asistente_Clave", "Asistente_PacienteId", "Asistente_PacienteNombre",
                "Asistente_EspecialidadId", "Asistente_EspecialidadNombre",
                "Asistente_Fecha", "Asistente_Horarios", "Asistente_Historial",
                "Asistente_PacienteDNI", "Asistente_PacienteNombres", "Asistente_PacienteApPaterno",
                "Asistente_PacienteApMaterno", "Asistente_PacienteEdad", "Asistente_PacienteSexo",
                "Asistente_PacienteTelefono", "Asistente_PacienteDireccion", "Asistente_ContinuarCita",
                "Asistente_Problema", "Asistente_MedicoDNI", "Asistente_MedicoNombres",
                "Asistente_MedicoApPaterno", "Asistente_MedicoApMaterno", "Asistente_MedicoEspecialidadId",
                "Asistente_MedicoEspecialidadNombre", "Asistente_EnfermeraDNI", "Asistente_EnfermeraNombres",
                "Asistente_EnfermeraApPaterno", "Asistente_EnfermeraApMaterno", "Asistente_EnfermeraTipo"
            };

            foreach (string clave in claves)
                HttpContext.Current.Session.Remove(clave);
        }

        private class HorarioOpcion
        {
            public int IdHorario { get; set; }
            public int IdMedico { get; set; }
            public string Hora { get; set; }
            public string Medico { get; set; }
        }
    }
}
