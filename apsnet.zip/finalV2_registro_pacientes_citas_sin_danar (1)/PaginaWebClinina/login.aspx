﻿<%@ Page Language="C#" AutoEventWireup="true" CodeBehind="login.aspx.cs" Inherits="PaginaWebClinina.login" %>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="es">
<head runat="server">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <meta name="description" content="API CJS SENA - Servicio de Citas Médicas"/>
    <title>API CJS SENA | Iniciar Sesión</title>
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="css/AdminLTE.css" rel="stylesheet" type="text/css" />
    <!-- CJS SENA: estilos visuales modernos -->
    <link href="css/cjs-modern.css" rel="stylesheet" type="text/css" />
    <link rel="icon" href="img/clinica_318-1538.jpg" />
</head>

<body class="cjs-login">
    <form id="form1" runat="server">
        <!-- Módulo de inicio de sesión: visible por defecto -->
        <div class="form-box" id="login-box" style="max-width:380px;width:100%;">
            <div id="loginModule">
                <asp:Login ID="LoginUser" runat="server" EnableViewState="false"
                    OnAuthenticate="LoginUser_Authenticate" Width="100%">
                    <LayoutTemplate>
                        <div class="header">
                            <i class="fa fa-heartbeat" style="margin-right:8px;"></i>
                            Bienvenido
                        </div>
                        <div class="body">
                            <div style="text-align:center;margin:-4px 0 22px;color:#718096;font-size:13px;">
                                <strong style="color:#243447;">API CJS SENA</strong><br />
                                Servicio de Citas Médicas
                            </div>
                            <div class="form-group">
                                <label style="font-size:12px;color:#526273;font-weight:600;">Usuario</label>
                                <asp:TextBox ID="UserName" runat="server" CssClass="form-control" placeholder="Ingrese su usuario"></asp:TextBox>
                            </div>
                            <div class="form-group">
                                <label style="font-size:12px;color:#526273;font-weight:600;">Contraseña</label>
                                <asp:TextBox ID="Password" runat="server" CssClass="form-control" placeholder="Ingrese su contraseña" TextMode="Password"></asp:TextBox>
                            </div>
                        </div>
                        <div class="footer">
                            <asp:Button ID="btnIngresar" CommandName="Login" runat="server" Text="Iniciar Sesión" CssClass="btn bg-blue btn-block" />
                        </div>
                    </LayoutTemplate>
                </asp:Login>
                <div style="background:#fff;border-top:1px solid #e5edf4;padding:18px 25px 22px;border-radius:0 0 12px 12px;text-align:center;">
                    <button type="button" class="btn btn-crear-usuario" onclick="mostrarRegistro();return false;">Crear usuario</button>
                    <p style="color:#718096;font-size:12px;margin:4px 0 0;">Regístrese para solicitar sus citas médicas</p>
                </div>
            </div>

            <!-- Módulo de registro: oculto hasta que el usuario lo solicite -->
            <div id="registerModule" style="display:none;background:#fff;border-radius:12px;overflow:hidden;">
                <div class="header" style="text-align:center;">Crear cuenta de invitado</div>
                <div style="padding:22px 25px 24px;">
                    <p style="text-align:center;color:#718096;font-size:12px;margin-bottom:18px;">Regístrese para solicitar sus citas médicas</p>
                    <asp:Label ID="lblRegistro" runat="server" EnableViewState="true" />
                    <div class="form-group">
                        <label style="font-size:12px;color:#526273;font-weight:600;">Nombre completo</label>
                        <asp:TextBox ID="txtRegNombre" runat="server" CssClass="form-control" MaxLength="50" placeholder="Ingrese su nombre completo" />
                    </div>
                    <div class="form-group">
                        <label style="font-size:12px;color:#526273;font-weight:600;">DNI / Documento</label>
                        <asp:TextBox ID="txtRegDni" runat="server" CssClass="form-control" MaxLength="8" placeholder="Número de documento" />
                    </div>
                    <div class="form-group">
                        <label style="font-size:12px;color:#526273;font-weight:600;">Nombre de usuario</label>
                        <asp:TextBox ID="txtRegUsuario" runat="server" CssClass="form-control" MaxLength="50" placeholder="Elija un usuario" />
                    </div>
                    <div class="form-group">
                        <label style="font-size:12px;color:#526273;font-weight:600;">Contraseña</label>
                        <asp:TextBox ID="txtRegClave" runat="server" CssClass="form-control" TextMode="Password" MaxLength="50" placeholder="Elija una contraseña" />
                    </div>
                    <asp:Button ID="btnRegistrarInvitado" runat="server" Text="Registrarme" CssClass="btn bg-blue btn-block" OnClick="btnRegistrarInvitado_Click" CausesValidation="false" />
                    <div style="text-align:center;margin-top:14px;">
                        <button type="button" class="btn btn-volver-inicio" onclick="mostrarLogin();return false;">Volver al menú de inicio</button>
                    </div>
                </div>
            </div>
        </div>
    </form>

    <script src="js/jquery-3.1.0.min.js"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script type="text/javascript">
        function mostrarRegistro() {
            document.getElementById('loginModule').style.display = 'none';
            document.getElementById('registerModule').style.display = 'block';
        }
        function mostrarLogin() {
            document.getElementById('registerModule').style.display = 'none';
            document.getElementById('loginModule').style.display = 'block';
        }
        // Tras un postback de registro, mantener abierto ese módulo para mostrar el resultado.
        window.addEventListener('load', function () {
            var mensaje = document.getElementById('<%= lblRegistro.ClientID %>');
            if (mensaje && mensaje.innerText && mensaje.innerText.trim().length > 0) {
                mostrarRegistro();
            }
        });
    </script>
</body>
</html>
