package co.edu.sena.clinica.modelo;

/**
 * Entidad del módulo de gestión de usuarios.
 * Sigue JavaBeans y nomenclatura CamelCase.
 */
public class Usuario {

    private int idUsuario;
    private String usuario;
    private String clave;
    private int idEmpleado;
    private String tipoUsuario;
    private boolean estado;

    public Usuario() {
    }

    public Usuario(String usuario, String clave, int idEmpleado, String tipoUsuario, boolean estado) {
        this.usuario = usuario;
        this.clave = clave;
        this.idEmpleado = idEmpleado;
        this.tipoUsuario = tipoUsuario;
        this.estado = estado;
    }

    public int getIdUsuario() { return idUsuario; }
    public void setIdUsuario(int idUsuario) { this.idUsuario = idUsuario; }
    public String getUsuario() { return usuario; }
    public void setUsuario(String usuario) { this.usuario = usuario; }
    public String getClave() { return clave; }
    public void setClave(String clave) { this.clave = clave; }
    public int getIdEmpleado() { return idEmpleado; }
    public void setIdEmpleado(int idEmpleado) { this.idEmpleado = idEmpleado; }
    public String getTipoUsuario() { return tipoUsuario; }
    public void setTipoUsuario(String tipoUsuario) { this.tipoUsuario = tipoUsuario; }
    public boolean isEstado() { return estado; }
    public void setEstado(boolean estado) { this.estado = estado; }
}
