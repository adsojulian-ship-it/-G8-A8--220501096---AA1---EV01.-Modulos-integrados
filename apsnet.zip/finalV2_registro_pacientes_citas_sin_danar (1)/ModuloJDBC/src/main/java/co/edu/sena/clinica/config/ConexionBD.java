package co.edu.sena.clinica.config;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Centraliza la conexión JDBC con SQL Server.
 * La configuración puede cambiarse mediante variables de entorno:
 * DB_URL, DB_USER y DB_PASSWORD.
 */
public final class ConexionBD {

    private static final String URL = obtener("DB_URL",
            "jdbc:sqlserver://localhost;instanceName=SQLEXPRESS;databaseName=CopiaDeseguridad SENA;integratedSecurity=true;encrypt=true;trustServerCertificate=true");
    private static final String USER = obtener("DB_USER", "");
    private static final String PASSWORD = obtener("DB_PASSWORD", "");

    private ConexionBD() {
    }

    public static Connection obtenerConexion() throws SQLException {
        if (USER.isBlank()) {
            return DriverManager.getConnection(URL);
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    private static String obtener(String nombre, String valorPorDefecto) {
        String valor = System.getenv(nombre);
        return valor == null || valor.isBlank() ? valorPorDefecto : valor;
    }
}
