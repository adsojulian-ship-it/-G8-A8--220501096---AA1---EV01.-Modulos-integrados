package co.edu.sena.clinica.app;

import co.edu.sena.clinica.dao.UsuarioDAO;
import co.edu.sena.clinica.modelo.Usuario;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

/**
 * Prueba funcional del CRUD JDBC.
 */
public class AplicacionCrud {

    private final UsuarioDAO usuarioDAO = new UsuarioDAO();
    private final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        new AplicacionCrud().iniciar();
    }

    private void iniciar() {
        int opcion;
        do {
            System.out.println("\n=== MÓDULO CRUD DE USUARIOS - JDBC ===");
            System.out.println("1. Insertar");
            System.out.println("2. Consultar");
            System.out.println("3. Actualizar");
            System.out.println("4. Eliminar");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = Integer.parseInt(scanner.nextLine());

            try {
                switch (opcion) {
                    case 1 -> insertar();
                    case 2 -> consultar();
                    case 3 -> actualizar();
                    case 4 -> eliminar();
                    case 0 -> System.out.println("Aplicación finalizada.");
                    default -> System.out.println("Opción no válida.");
                }
            } catch (SQLException ex) {
                System.out.println("Error de base de datos: " + ex.getMessage());
            }
        } while (opcion != 0);
    }

    private void insertar() throws SQLException {
        Usuario usuario = new Usuario();
        System.out.print("Usuario: ");
        usuario.setUsuario(scanner.nextLine());
        System.out.print("Clave: ");
        usuario.setClave(scanner.nextLine());
        System.out.print("Id empleado: ");
        usuario.setIdEmpleado(Integer.parseInt(scanner.nextLine()));
        System.out.print("Tipo de usuario: ");
        usuario.setTipoUsuario(scanner.nextLine());
        usuario.setEstado(true);

        System.out.println(usuarioDAO.insertar(usuario)
                ? "Usuario registrado correctamente."
                : "No fue posible registrar el usuario.");
    }

    private void consultar() throws SQLException {
        List<Usuario> usuarios = usuarioDAO.consultar();
        for (Usuario usuario : usuarios) {
            System.out.printf("%d | %s | %s%n",
                    usuario.getIdUsuario(), usuario.getUsuario(), usuario.getTipoUsuario());
        }
    }

    private void actualizar() throws SQLException {
        Usuario usuario = new Usuario();
        System.out.print("Id usuario: ");
        usuario.setIdUsuario(Integer.parseInt(scanner.nextLine()));
        System.out.print("Nuevo usuario: ");
        usuario.setUsuario(scanner.nextLine());
        System.out.print("Nueva clave: ");
        usuario.setClave(scanner.nextLine());
        System.out.print("Nuevo tipo: ");
        usuario.setTipoUsuario(scanner.nextLine());

        System.out.println(usuarioDAO.actualizar(usuario)
                ? "Usuario actualizado correctamente."
                : "No fue posible actualizar el usuario.");
    }

    private void eliminar() throws SQLException {
        System.out.print("Id usuario a eliminar: ");
        int idUsuario = Integer.parseInt(scanner.nextLine());

        System.out.println(usuarioDAO.eliminar(idUsuario)
                ? "Usuario eliminado correctamente."
                : "No fue posible eliminar el usuario.");
    }
}
