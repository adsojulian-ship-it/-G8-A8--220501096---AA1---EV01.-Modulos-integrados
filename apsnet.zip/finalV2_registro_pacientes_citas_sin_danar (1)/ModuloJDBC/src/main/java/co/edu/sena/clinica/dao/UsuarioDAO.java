package co.edu.sena.clinica.dao;

import co.edu.sena.clinica.config.ConexionBD;
import co.edu.sena.clinica.modelo.Usuario;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO JDBC. Implementa el CRUD usando los procedimientos almacenados
 * existentes en SQL Server para no alterar la base de datos del proyecto.
 */
public class UsuarioDAO {

    public boolean insertar(Usuario usuario) throws SQLException {
        String sql = "{call spRegistrarUsuario(?, ?, ?, ?, ?)}";
        try (Connection conexion = ConexionBD.obtenerConexion();
             CallableStatement sentencia = conexion.prepareCall(sql)) {

            sentencia.setString(1, usuario.getUsuario());
            sentencia.setString(2, usuario.getClave());
            sentencia.setInt(3, usuario.getIdEmpleado());
            sentencia.setString(4, usuario.getTipoUsuario());
            sentencia.setBoolean(5, usuario.isEstado());

            return sentencia.executeUpdate() > 0;
        }
    }

    public List<Usuario> consultar() throws SQLException {
        String sql = "{call spListarUsuarios()}";
        List<Usuario> usuarios = new ArrayList<>();

        try (Connection conexion = ConexionBD.obtenerConexion();
             CallableStatement sentencia = conexion.prepareCall(sql);
             ResultSet resultado = sentencia.executeQuery()) {

            while (resultado.next()) {
                Usuario usuario = new Usuario();
                usuario.setIdUsuario(resultado.getInt("idUsuario"));
                usuario.setUsuario(resultado.getString("usuario"));
                usuario.setClave(resultado.getString("clave"));
                usuario.setTipoUsuario(resultado.getString("tipoUser"));
                usuario.setEstado(true);
                usuarios.add(usuario);
            }
        }
        return usuarios;
    }

    public boolean actualizar(Usuario usuario) throws SQLException {
        String sql = "{call spActualizarDatosUsuario(?, ?, ?, ?)}";
        try (Connection conexion = ConexionBD.obtenerConexion();
             CallableStatement sentencia = conexion.prepareCall(sql)) {

            sentencia.setInt(1, usuario.getIdUsuario());
            sentencia.setString(2, usuario.getUsuario());
            sentencia.setString(3, usuario.getClave());
            sentencia.setString(4, usuario.getTipoUsuario());

            return sentencia.executeUpdate() > 0;
        }
    }

    public boolean eliminar(int idUsuario) throws SQLException {
        String sql = "{call spEliminarUsuario(?)}";
        try (Connection conexion = ConexionBD.obtenerConexion();
             CallableStatement sentencia = conexion.prepareCall(sql)) {

            sentencia.setInt(1, idUsuario);
            return sentencia.executeUpdate() > 0;
        }
    }
}
