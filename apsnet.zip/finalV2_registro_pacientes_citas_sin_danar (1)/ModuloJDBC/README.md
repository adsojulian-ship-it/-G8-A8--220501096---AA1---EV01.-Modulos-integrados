# Módulo JDBC - Clínica Asistente IA

Este módulo adapta el proyecto a la evidencia **GA7-220501096-AA5-EV04 – Codificación del módulo del proyecto**.

## Tecnología
- Java 17
- JDBC
- Microsoft SQL Server
- Maven
- Git/GitHub

## Arquitectura
```
co.edu.sena.clinica
├── app       -> AplicacionCrud
├── config    -> ConexionBD
├── dao       -> UsuarioDAO
└── modelo    -> Usuario
```

## CRUD implementado
- **Create / Inserción:** `insertar()` → `spRegistrarUsuario`
- **Read / Consulta:** `consultar()` → `spListarUsuarios`
- **Update / Actualización:** `actualizar()` → `spActualizarDatosUsuario`
- **Delete / Eliminación:** `eliminar()` → `spEliminarUsuario`

El módulo utiliza `CallableStatement`, por lo que aprovecha los procedimientos almacenados existentes y no modifica la estructura de la base de datos.

## Configuración
Por defecto utiliza la instancia SQL Server del proyecto original:
`user\SQLEXPRESS` y la base `CopiaDeseguridad SENA`.

Se recomienda configurar variables de entorno:
- `DB_URL`
- `DB_USER`
- `DB_PASSWORD`

## Ejecución
```bash
mvn clean compile
mvn exec:java -Dexec.mainClass="co.edu.sena.clinica.app.AplicacionCrud"
```

## Versionamiento
Inicializar en la carpeta raíz:
```bash
git init
git add .
git commit -m "feat: implementación módulo CRUD JDBC"
git branch -M main
git remote add origin URL_DEL_REPOSITORIO
git push -u origin main
```
